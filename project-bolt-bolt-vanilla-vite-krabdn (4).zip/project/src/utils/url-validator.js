/**
 * Validates if a string is a valid URL
 * @param {string} url - URL to validate
 * @returns {boolean} True if valid URL
 */
export function isValidUrl(url) {
  try {
    new URL(url.startsWith('http') ? url : `https://${url}`);
    return true;
  } catch {
    return false;
  }
}

/**
 * Extracts domain from URL
 * @param {string} url - URL to process
 * @returns {string} Domain without protocol and www
 */
export function extractDomainFromUrl(url) {
  try {
    const urlObj = new URL(url.startsWith('http') ? url : `https://${url}`);
    return urlObj.hostname.replace(/^www\./, '');
  } catch {
    return url;
  }
}

/**
 * Extracts company name from URL
 * @param {string} url - URL to process
 * @returns {string} Company name derived from domain
 */
export function extractCompanyNameFromUrl(url) {
  try {
    const domain = extractDomainFromUrl(url);
    return domain.split('.')[0]
      .replace(/-/g, ' ')
      .replace(/\b\w/g, l => l.toUpperCase());
  } catch {
    return url;
  }
}
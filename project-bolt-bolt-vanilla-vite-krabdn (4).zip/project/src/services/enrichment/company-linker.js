import { supabase } from '../../config/supabase';
import { logger } from '../../utils/logger';
import { findCompanyByLinkedInId, findCompanyByName } from '../database/company';
import { storeEmployeeCompanyRelationship } from '../database/relationship';

export async function linkCompanies() {
  try {
    // Find employees with work experience
    const { data: employees, error } = await supabase
      .from('employees')
      .select(`
        linkedin_id,
        work_experience,
        current_positions
      `)
      .not('work_experience', 'is', null)
      .not('work_experience', 'eq', '[]')
      .not('enriched_at', 'is', null);

    if (error) throw error;

    logger.info(`Found ${employees.length} employees to process for company linking`);

    for (const employee of employees) {
      const positions = [
        ...(employee.current_positions || []),
        ...(employee.work_experience || [])
      ];

      for (const position of positions) {
        if (!position.company) continue;

        // Try linking by LinkedIn ID first
        let company = position.company_id ? 
          await findCompanyByLinkedInId(position.company_id) : null;

        // If no match by ID, try matching by name
        if (!company) {
          company = await findCompanyByName(position.company);
        }

        // Store relationship even if company not found (will store just the name)
        await storeEmployeeCompanyRelationship(employee.linkedin_id, {
          ...position,
          company_id: company?.id
        });
      }
    }

    logger.success('Company linking process completed');
  } catch (error) {
    logger.error('Company linking process failed:', error);
    throw error;
  }
}
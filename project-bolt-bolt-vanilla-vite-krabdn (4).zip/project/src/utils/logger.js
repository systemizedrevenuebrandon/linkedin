class Logger {
  constructor() {
    this.uiCallbacks = {
      onProgress: null,
      onComplete: null,
      onSalesNavUrl: null,
      onError: null
    };
    this.logs = [];
    this.startTime = null;
  }

  setCallbacks(callbacks) {
    this.uiCallbacks = { ...this.uiCallbacks, ...callbacks };
  }

  getTimestamp() {
    return new Date().toISOString();
  }

  getElapsedTime() {
    if (!this.startTime) return '';
    const elapsed = Date.now() - this.startTime;
    return `[${(elapsed / 1000).toFixed(2)}s]`;
  }

  formatConsoleMessage(level, message, data = null) {
    const icons = {
      DEBUG: '🔍',
      INFO: 'ℹ️',
      SUCCESS: '✅',
      WARN: '⚠️',
      ERROR: '❌'
    };

    const colors = {
      DEBUG: '\x1b[90m', // Gray
      INFO: '\x1b[36m',  // Cyan
      SUCCESS: '\x1b[32m', // Green
      WARN: '\x1b[33m',  // Yellow
      ERROR: '\x1b[31m', // Red
      RESET: '\x1b[0m'
    };

    const timestamp = this.getTimestamp();
    const elapsed = this.getElapsedTime();
    
    // Store log for potential retrieval
    this.logs.push({ timestamp, level, message, data });

    // Format terminal output
    const prefix = `${colors[level]}${icons[level]} ${level}${colors.RESET}`;
    const time = `${colors.DEBUG}${timestamp}${elapsed}${colors.RESET}`;
    
    console.log(`${prefix} ${time}`);
    console.log(`${colors[level]}${message}${colors.RESET}`);
    
    if (data) {
      console.log(`${colors.DEBUG}Data:${colors.RESET}`, data);
    }
    console.log(''); // Empty line for readability
  }

  startProcess() {
    this.startTime = Date.now();
    this.logs = [];
  }

  log(level, message, data = null) {
    // Log to terminal
    this.formatConsoleMessage(level, message, data);

    // Handle UI callbacks
    if (level === 'ERROR' && this.uiCallbacks.onError) {
      this.uiCallbacks.onError(message);
    } else if (level === 'SUCCESS') {
      if (message.includes('Found LinkedIn page') && this.uiCallbacks.onProgress) {
        this.uiCallbacks.onProgress();
      } else if (message.includes('Processing complete') && this.uiCallbacks.onComplete) {
        this.uiCallbacks.onComplete(this.extractStats(message));
      } else if (message.includes('Generated Sales Navigator URL') && this.uiCallbacks.onSalesNavUrl) {
        this.uiCallbacks.onSalesNavUrl(data);
      }
    }
  }

  extractStats(message) {
    const matches = message.match(/Total websites: (\d+)\s*- Successful: (\d+)\s*- Failed: (\d+)/);
    if (matches) {
      return {
        total: parseInt(matches[1]),
        successful: parseInt(matches[2]),
        failed: parseInt(matches[3])
      };
    }
    return null;
  }

  getLogs() {
    return this.logs;
  }

  clearLogs() {
    this.logs = [];
    this.startTime = null;
  }

  debug(message, data) { this.log('DEBUG', message, data); }
  info(message, data) { this.log('INFO', message, data); }
  success(message, data) { this.log('SUCCESS', message, data); }
  warn(message, data) { this.log('WARN', message, data); }
  error(message, data) { this.log('ERROR', message, data); }
}

export const logger = new Logger();
import { logger } from '../utils/logger.js';
import { config } from '../config/api-config.js';
import { chunkArray } from '../utils/array-utils.js';

const BATCH_SIZE = 80;
const SEARCH_BASE_URL = 'https://www.linkedin.com/sales/search/people';

function generateSearchUrl(filters) {
  const encodedFilters = encodeURIComponent(filters);
  return `${SEARCH_BASE_URL}?query=(recentSearchParam%3A(doLogHistory%3Atrue)%2Cfilters%3AList(${filters}))`;
}

function formatCompanyIdForUrl(companyId) {
  return `(id%3Aurn%253Ali%253Aorganization%253A${companyId}%2CselectionType%3AINCLUDED)`;
}

function formatCompanyNameForUrl(companyName) {
  const encodedName = encodeURIComponent(companyName.trim());
  return `(text%3A${encodedName}%2CselectionType%3AINCLUDED)`;
}

function formatTitleForUrl(title) {
  const encodedTitle = encodeURIComponent(title.trim());
  return `(text%3A${encodedTitle}%2CselectionType%3AINCLUDED)`;
}

function generateTitleFilter(titles) {
  if (!titles?.length) return '';
  const titleValues = titles.map(formatTitleForUrl).join('%2C');
  return `(type%3ACURRENT_TITLE%2Cvalues%3AList(${titleValues}))`;
}

function generateCompanyFilter(companies, type = 'id') {
  const values = companies.map(company => {
    if (type === 'id' && company.linkedin_id) {
      return formatCompanyIdForUrl(company.linkedin_id);
    }
    return formatCompanyNameForUrl(company.name);
  }).join('%2C');
  
  return `(type%3ACURRENT_COMPANY%2Cvalues%3AList(${values}))`;
}

export function generateSalesNavUrls(companies, titles = []) {
  try {
    if (!Array.isArray(companies) || companies.length === 0) {
      logger.warn('No companies provided for URL generation');
      return [];
    }

    // Separate companies into ID-based and name-based searches
    const idBasedCompanies = companies.filter(c => c.linkedin_id);
    const nameBasedCompanies = companies.filter(c => !c.linkedin_id && c.name);

    logger.info(`Generating URLs for ${idBasedCompanies.length} companies with IDs and ${nameBasedCompanies.length} companies without IDs`);

    const urls = [];

    // Generate URLs for companies with IDs
    if (idBasedCompanies.length > 0) {
      const idBatches = chunkArray(idBasedCompanies, BATCH_SIZE);
      idBatches.forEach((batch, index) => {
        const filters = [
          generateCompanyFilter(batch, 'id'),
          generateTitleFilter(titles)
        ].filter(Boolean).join('%2C');

        const url = generateSearchUrl(filters);
        urls.push({
          url,
          type: 'id-based',
          batchNumber: index + 1,
          companies: batch.map(c => c.name || `Company ID: ${c.linkedin_id}`),
          companyCount: batch.length
        });
        logger.success(`Generated ID-based URL for batch ${index + 1} with ${batch.length} companies`);
      });
    }

    // Generate URLs for companies without IDs (name-based search)
    if (nameBasedCompanies.length > 0) {
      const nameBatches = chunkArray(nameBasedCompanies, BATCH_SIZE);
      nameBatches.forEach((batch, index) => {
        const filters = [
          generateCompanyFilter(batch, 'name'),
          generateTitleFilter(titles)
        ].filter(Boolean).join('%2C');

        const url = generateSearchUrl(filters);
        urls.push({
          url,
          type: 'name-based',
          batchNumber: index + 1,
          companies: batch.map(c => c.name),
          companyCount: batch.length
        });
        logger.success(`Generated name-based URL for batch ${index + 1} with ${batch.length} companies`);
      });
    }

    logger.success(`Generated ${urls.length} Sales Navigator URLs`);
    return urls;
  } catch (error) {
    logger.error(`Failed to generate Sales Navigator URLs: ${error.message}`);
    return [];
  }
}

export function generateSingleSalesNavUrl(company) {
  try {
    if (!company) {
      throw new Error('Company data is required');
    }

    if (company.linkedin_id) {
      return `${config.salesNavigator.baseUrl}${company.linkedin_id}`;
    }

    if (company.name) {
      const filter = generateCompanyFilter([{ name: company.name }], 'name');
      return generateSearchUrl(filter);
    }

    throw new Error('Company must have either an ID or name');
  } catch (error) {
    logger.error(`Failed to generate single Sales Navigator URL: ${error.message}`);
    return null;
  }
}
import { supabase } from '../config/supabase';
import { logger } from '../utils/logger';

export async function storeCompanyData(company) {
  try {
    if (!company.name) {
      logger.warn('No company name provided, skipping');
      return null;
    }

    // First check if company exists by LinkedIn ID or URL
    let existingCompany = null;
    if (company.linkedin_id || company.linkedin_url) {
      const { data } = await supabase
        .from('companies')
        .select('id')
        .or(`linkedin_id.eq.${company.linkedin_id},linkedin_url.eq.${company.linkedin_url}`)
        .maybeSingle();
      
      existingCompany = data;
    }

    // Insert or update company
    const { data, error } = await supabase
      .from('companies')
      .upsert({
        id: existingCompany?.id,
        linkedin_id: company.linkedin_id || null,
        name: company.name,
        website: company.website,
        linkedin_url: company.linkedin_url || null,
        industry: company.industry,
        employee_count: company.employee_count,
        description: company.description,
        headquarters: company.headquarters,
        updated_at: new Date().toISOString()
      })
      .select()
      .single();

    if (error) throw error;
    logger.success(`Stored company data for ${company.name}`);
    return data;
  } catch (error) {
    logger.error(`Failed to store company data for ${company.name}: ${error.message}`);
    return null;
  }
}

export async function storeEmployeeData(employee, searchData) {
  try {
    if (!employee?.linkedin_id) {
      throw new Error('No LinkedIn ID provided for employee');
    }

    // Store only basic employee data initially - no company relationships
    const { data: employeeData, error: employeeError } = await supabase
      .from('employees')
      .upsert({
        linkedin_id: employee.linkedin_id,
        first_name: employee.first_name,
        last_name: employee.last_name,
        full_name: employee.full_name,
        headline: employee.headline,
        location: employee.location,
        industry: employee.industry,
        linkedin_url: employee.linkedin_url,
        profile_image_url: employee.profile_image_url,
        search_metadata: {
          batch: searchData.batchNumber,
          search_type: searchData.type,
          timestamp: new Date().toISOString()
        }
      }, {
        onConflict: 'linkedin_id'
      })
      .select()
      .single();

    if (employeeError) throw employeeError;
    logger.success(`Stored basic employee data for ${employee.full_name}`);
    return employeeData;
  } catch (error) {
    logger.error(`Failed to store employee data: ${error.message}`);
    return null;
  }
}

export async function updateEnrichedProfile(enrichedData) {
  try {
    const { error } = await supabase
      .from('employees')
      .update({
        work_experience: enrichedData.work_experience,
        current_positions: enrichedData.current_positions,
        education: enrichedData.education,
        enriched_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .eq('linkedin_url', enrichedData.linkedin_url);

    if (error) throw error;
    logger.success(`Updated profile with enriched data: ${enrichedData.linkedin_url}`);
    return true;
  } catch (error) {
    logger.error(`Failed to update enriched profile: ${error.message}`);
    return false;
  }
}

export async function findEmployeesNeedingEnrichment() {
  try {
    const { data, error } = await supabase
      .from('employees')
      .select('linkedin_id, linkedin_url')
      .is('enriched_at', null)
      .not('linkedin_url', 'is', null)
      .order('created_at', { ascending: false })
      .limit(100);

    if (error) throw error;
    return data.filter(emp => emp.linkedin_url?.includes('linkedin.com/in/'));
  } catch (error) {
    logger.error('Failed to find employees needing enrichment:', error);
    return [];
  }
}

export async function findEmployeesNeedingNameCleaning() {
  try {
    const { data, error } = await supabase
      .from('employees')
      .select('linkedin_id, full_name')
      .is('name_cleaned_at', null)
      .not('full_name', 'is', null)
      .order('created_at', { ascending: false })
      .limit(100);

    if (error) throw error;
    return data;
  } catch (error) {
    logger.error('Failed to find employees needing name cleaning:', error);
    return [];
  }
}

export async function storeSearchResult(searchData, employeeCount) {
  try {
    const { error } = await supabase
      .from('search_results')
      .insert({
        batch_number: searchData.batchNumber,
        search_type: searchData.type,
        search_url: searchData.url,
        companies: searchData.companies,
        employee_count: employeeCount
      });

    if (error) throw error;
    logger.success(`Stored search result for batch ${searchData.batchNumber}`);
  } catch (error) {
    logger.error(`Failed to store search result: ${error.message}`);
  }
}
import { supabase } from '../config/supabase';
import { logger } from '../utils/logger';

export async function initializeDatabase() {
  try {
    logger.info('Initializing database tables...');

    // Clear existing data
    const tables = ['search_results', 'employee_companies', 'employees', 'companies'];
    
    for (const table of tables) {
      const { error } = await supabase
        .from(table)
        .delete()
        .neq('id', 0);

      if (error && !error.message.includes('does not exist')) {
        logger.warn(`Error clearing ${table}: ${error.message}`);
      }
    }

    // Create stored procedures for batch operations
    const createFunctionsSql = `
      -- Function to update employee enrichment data
      CREATE OR REPLACE FUNCTION update_employee_enrichment(
        p_linkedin_url TEXT,
        p_work_experience JSONB,
        p_current_positions JSONB,
        p_education JSONB
      ) RETURNS void AS $$
      BEGIN
        UPDATE employees 
        SET 
          work_experience = p_work_experience,
          current_positions = p_current_positions,
          education = p_education,
          enriched_at = NOW(),
          updated_at = NOW()
        WHERE linkedin_url = p_linkedin_url;
      END;
      $$ LANGUAGE plpgsql;

      -- Function to update employee names
      CREATE OR REPLACE FUNCTION update_employee_names(
        p_linkedin_id TEXT,
        p_first_name TEXT,
        p_last_name TEXT,
        p_full_name TEXT
      ) RETURNS void AS $$
      BEGIN
        UPDATE employees 
        SET 
          first_name = p_first_name,
          last_name = p_last_name,
          full_name = p_full_name,
          name_cleaned_at = NOW(),
          updated_at = NOW()
        WHERE linkedin_id = p_linkedin_id;
      END;
      $$ LANGUAGE plpgsql;

      -- Grant execute permissions
      GRANT EXECUTE ON FUNCTION update_employee_enrichment TO anon;
      GRANT EXECUTE ON FUNCTION update_employee_names TO anon;
    `;

    const { error: functionError } = await supabase.rpc('execute', { 
      query: createFunctionsSql 
    });

    if (functionError) {
      logger.warn(`Error creating functions: ${functionError.message}`);
    }

    logger.success('Database initialized successfully');
    return true;
  } catch (error) {
    logger.error('Failed to initialize database:', error);
    throw error;
  }
}
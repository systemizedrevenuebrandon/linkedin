import axios from 'axios';
import { config } from '../config/api-config';
import { logger } from '../utils/logger';
import { RateController } from '../utils/rate-control';
import { supabase } from '../config/supabase';
import { cleanName } from '../utils/name-cleaner';

const rateController = new RateController({
  baseDelay: 2000,
  maxDelay: 30000,
  maxRetries: 3,
  maxRequestsPerWindow: 5,
  windowSize: 60000
});

export async function enrichProfiles(profiles) {
  try {
    if (!Array.isArray(profiles) || profiles.length === 0) {
      return [];
    }

    logger.info(`Starting enrichment for ${profiles.length} profiles`);
    const enrichedProfiles = [];

    // Process in batches of 25 to avoid rate limits
    for (let i = 0; i < profiles.length; i += 25) {
      const batch = profiles.slice(i, i + 25);
      const linkedinUrls = batch
        .map(p => p.linkedin_url)
        .filter(url => url?.includes('linkedin.com/in/'));

      if (linkedinUrls.length === 0) continue;

      try {
        const enrichedBatch = await rateController.enqueue(() => 
          fetchEnrichedProfiles(linkedinUrls)
        );

        for (const enrichedProfile of enrichedBatch) {
          const originalProfile = batch.find(p => 
            p.linkedin_url === enrichedProfile.linkedin_url
          );

          if (originalProfile && enrichedProfile) {
            // Clean the name
            const cleanedName = await cleanName(enrichedProfile.name);
            
            // Update profile with enriched and cleaned data
            const success = await updateProfileInDatabase({
              ...enrichedProfile,
              ...cleanedName,
              linkedin_id: originalProfile.linkedin_id
            });

            if (success) {
              enrichedProfiles.push(enrichedProfile);
              logger.success(`Enriched and cleaned profile for ${cleanedName.full_name}`);
            }
          }
        }

        if (i + 25 < profiles.length) {
          logger.info('Waiting before next batch...');
          await new Promise(resolve => setTimeout(resolve, 5000));
        }
      } catch (error) {
        logger.error(`Failed to enrich batch: ${error.message}`);
      }
    }

    return enrichedProfiles;
  } catch (error) {
    logger.error('Profile enrichment failed:', error);
    throw error;
  }
}

async function fetchEnrichedProfiles(linkedinUrls) {
  try {
    const response = await axios.post(
      config.rapidApi.profilesUrl,
      { links: linkedinUrls },
      {
        headers: {
          'Content-Type': 'application/json',
          'X-RapidAPI-Key': config.rapidApi.apiKey,
          'X-RapidAPI-Host': config.rapidApi.host
        }
      }
    );

    if (!response.data?.data) {
      throw new Error('Invalid response from enrichment API');
    }

    return response.data.data
      .filter(item => item?.data)
      .map(item => ({
        linkedin_url: item.entry,
        work_experience: mapWorkExperience(item.data.experiences),
        current_positions: mapCurrentPositions(item.data.experiences),
        education: mapEducation(item.data.educations),
        name: item.data.fullName,
        headline: item.data.headline
      }));
  } catch (error) {
    logger.error('Profile enrichment API error:', error);
    throw error;
  }
}

async function updateProfileInDatabase(profile) {
  try {
    const { error } = await supabase
      .from('employees')
      .update({
        first_name: profile.first_name,
        last_name: profile.last_name,
        full_name: profile.full_name,
        work_experience: profile.work_experience,
        current_positions: profile.current_positions,
        education: profile.education,
        enriched_at: new Date().toISOString(),
        name_cleaned_at: new Date().toISOString()
      })
      .eq('linkedin_id', profile.linkedin_id);

    if (error) throw error;
    return true;
  } catch (error) {
    logger.error(`Failed to update enriched profile: ${error.message}`);
    return false;
  }
}

function mapWorkExperience(experiences) {
  if (!Array.isArray(experiences)) return [];
  return experiences.map(exp => ({
    company: exp.companyName,
    company_id: exp.companyId,
    role: exp.title,
    industry: exp.industry,
    start: exp.dateRange?.start,
    end: exp.dateRange?.end
  }));
}

function mapCurrentPositions(experiences) {
  if (!Array.isArray(experiences)) return [];
  return experiences
    .filter(exp => !exp.dateRange?.end)
    .map(exp => ({
      company: exp.companyName,
      company_id: exp.companyId,
      role: exp.title,
      description: exp.description,
      location: exp.location,
      start: exp.dateRange?.start
    }));
}

function mapEducation(educations) {
  if (!Array.isArray(educations)) return [];
  return educations.map(edu => ({
    degree: edu.degree,
    school: edu.schoolName,
    school_id: edu.schoolId,
    start: edu.dateRange?.start,
    end: edu.dateRange?.end
  }));
}
import axios from 'axios';
import { logger } from './logger.js';

/**
 * Checks if a website is accessible
 * @param {string} url - The URL to check
 * @returns {Promise<boolean>} True if website is accessible
 */
export async function checkWebsiteAvailability(url) {
  try {
    const normalizedUrl = url.startsWith('http') ? url : `https://${url}`;
    
    try {
      const response = await axios.get(normalizedUrl, {
        timeout: 5000,
        maxRedirects: 5,
        validateStatus: status => status < 400
      });
      return true;
    } catch (error) {
      // If we get a CORS error, the website exists but blocks browser requests
      if (error.message.includes('CORS') || error.code === 'ERR_NETWORK') {
        return true;
      }

      // For connection refused or timeout, try HTTP
      if (error.code === 'ECONNREFUSED' || error.code === 'ETIMEDOUT') {
        if (!normalizedUrl.startsWith('http://')) {
          const httpUrl = `http://${normalizedUrl.replace('https://', '')}`;
          try {
            await axios.get(httpUrl, {
              timeout: 5000,
              maxRedirects: 5,
              validateStatus: status => status < 400
            });
            return true;
          } catch (httpError) {
            // Again, CORS errors mean the site exists
            if (httpError.message.includes('CORS') || httpError.code === 'ERR_NETWORK') {
              return true;
            }
          }
        }
      }

      logger.warn(`Website not accessible: ${url} (${error.message})`);
      return false;
    }
  } catch (error) {
    logger.error(`Error checking website availability: ${error.message}`);
    return false;
  }
}
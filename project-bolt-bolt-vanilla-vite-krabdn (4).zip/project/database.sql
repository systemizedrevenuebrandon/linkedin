-- Drop existing tables if they exist
DROP TABLE IF EXISTS search_results CASCADE;
DROP TABLE IF EXISTS employee_companies CASCADE;
DROP TABLE IF EXISTS employees CASCADE;
DROP TABLE IF EXISTS companies CASCADE;

-- Create tables
CREATE TABLE companies (
    id BIGSERIAL PRIMARY KEY,
    linkedin_id TEXT,
    name TEXT NOT NULL,
    website TEXT,
    linkedin_url TEXT,
    industry TEXT,
    employee_count INTEGER,
    description TEXT,
    headquarters TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(linkedin_id) WHERE linkedin_id IS NOT NULL,
    UNIQUE(linkedin_url) WHERE linkedin_url IS NOT NULL
);

CREATE TABLE employees (
    id BIGSERIAL PRIMARY KEY,
    linkedin_id TEXT UNIQUE NOT NULL,
    first_name TEXT,
    last_name TEXT,
    full_name TEXT,
    headline TEXT,
    location TEXT,
    industry TEXT,
    linkedin_url TEXT UNIQUE,
    profile_image_url TEXT,
    current_positions JSONB DEFAULT '[]'::jsonb,
    education JSONB DEFAULT '[]'::jsonb,
    work_experience JSONB DEFAULT '[]'::jsonb,
    search_metadata JSONB,
    enriched_at TIMESTAMPTZ,
    name_cleaned_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE employee_companies (
    id BIGSERIAL PRIMARY KEY,
    employee_id TEXT NOT NULL,
    company_id BIGINT,
    company_name TEXT NOT NULL,
    is_current BOOLEAN DEFAULT true,
    role TEXT NOT NULL DEFAULT 'Employee',
    start_date DATE,
    end_date DATE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    FOREIGN KEY (employee_id) REFERENCES employees(linkedin_id) ON DELETE CASCADE,
    FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE SET NULL,
    UNIQUE(employee_id, company_name, role)
);

CREATE TABLE search_results (
    id BIGSERIAL PRIMARY KEY,
    batch_number INTEGER NOT NULL,
    search_type TEXT NOT NULL,
    search_url TEXT NOT NULL,
    companies JSONB,
    employee_count INTEGER,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create indexes
CREATE INDEX idx_companies_linkedin_id ON companies(linkedin_id) WHERE linkedin_id IS NOT NULL;
CREATE INDEX idx_companies_linkedin_url ON companies(linkedin_url) WHERE linkedin_url IS NOT NULL;
CREATE INDEX idx_companies_name ON companies(name);

CREATE INDEX idx_employees_linkedin_id ON employees(linkedin_id);
CREATE INDEX idx_employees_linkedin_url ON employees(linkedin_url);
CREATE INDEX idx_employees_enriched ON employees(enriched_at) WHERE enriched_at IS NULL;
CREATE INDEX idx_employees_names ON employees(name_cleaned_at) WHERE name_cleaned_at IS NULL;

CREATE INDEX idx_employee_companies_employee_id ON employee_companies(employee_id);
CREATE INDEX idx_employee_companies_company_id ON employee_companies(company_id);
CREATE INDEX idx_employee_companies_company_name ON employee_companies(company_name);
CREATE INDEX idx_employee_companies_dates ON employee_companies(start_date, end_date);

CREATE INDEX idx_search_results_batch ON search_results(batch_number);
CREATE INDEX idx_search_results_created ON search_results(created_at);

-- Grant permissions
GRANT ALL ON ALL TABLES IN SCHEMA public TO anon;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO anon;
GRANT USAGE ON SCHEMA public TO anon;
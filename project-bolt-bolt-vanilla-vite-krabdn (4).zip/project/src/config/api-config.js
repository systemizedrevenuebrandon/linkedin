export const config = {
  serper: {
    baseUrl: 'https://google.serper.dev/search',
    apiKey: 'bf648f5e767bc506d2e28fd7be149e0a8deaf0d9'
  },
  rapidApi: {
    baseUrl: 'https://linkedin-bulk-data-scraper.p.rapidapi.com/companies',
    profilesUrl: 'https://linkedin-bulk-data-scraper.p.rapidapi.com/profiles',
    apiKey: 'dc0a5eab9bmsh6bac97403b1b3e7p1806bbjsnf2dede2159c5',
    host: 'linkedin-bulk-data-scraper.p.rapidapi.com'
  },
  salesNavigator: {
    baseUrl: 'https://www.linkedin.com/sales/company/',
    searchBaseUrl: 'https://www.linkedin.com/sales/search/people'
  },
  unipile: {
    baseUrl: 'https://api3.unipile.com:13352/api/v1/linkedin/search',
    apiKey: 'DRylVUqt.Z/dufCfwyLKrLD8SmuSjMaObBsh+T4hkoCdkE1qLSdQ=',
    accounts: [
      'K9nq8z3pTA-2at-ImShcIQ',
      'UJcXW8JlR7mGHLf5nUIMgg'
    ],
    dailyLimit: 2500,
    resultsPerPage: 100
  },
  openai: {
    apiKey: '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',
    model: 'gpt-4o-mini'
  }
};
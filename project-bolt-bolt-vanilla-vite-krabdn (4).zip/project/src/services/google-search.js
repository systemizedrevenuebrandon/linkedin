import axios from 'axios';
import { config } from '../config/api-config.js';
import { logger } from '../utils/logger.js';
import { extractDomainFromUrl } from '../utils/url-validator.js';

function isValidLinkedInCompanyUrl(url) {
  return url.includes('linkedin.com/company/') && 
         !url.includes('/life') && 
         !url.includes('/posts') && 
         !url.includes('/jobs') &&
         !url.includes('/people') &&
         !url.includes('/school');
}

async function searchGoogle(query) {
  try {
    logger.debug(`Executing Google search: ${query}`);
    const response = await axios.post(config.serper.baseUrl, {
      q: query,
      gl: 'us',
      hl: 'en',
      api_key: config.serper.apiKey
    });
    return response.data.organic || [];
  } catch (error) {
    logger.error(`Google search error for query "${query}": ${error.message}`);
    return [];
  }
}

export async function findLinkedInCompanyPage({ website, name }) {
  const domain = extractDomainFromUrl(website);
  const cleanDomain = domain.replace(/^www\./, '');
  
  // Prioritize website-based searches
  const searchQueries = [
    // Website-based searches first (most accurate)
    {
      query: `site:linkedin.com/company "${cleanDomain}"`,
      type: 'domain-exact'
    },
    {
      query: `site:linkedin.com/company "${website}"`,
      type: 'full-url'
    },
    {
      query: `"${cleanDomain}" company site:linkedin.com/company`,
      type: 'domain-context'
    }
  ];

  // Add name-based searches if a company name is provided
  if (name) {
    searchQueries.push(
      {
        query: `site:linkedin.com/company "${name}" "${cleanDomain}"`,
        type: 'name-domain'
      },
      {
        query: `site:linkedin.com/company "${name}"`,
        type: 'name-only'
      }
    );
  }

  logger.info(`Starting LinkedIn search for ${name || cleanDomain} (${website})`);
  
  // Try each search query sequentially
  for (const { query, type } of searchQueries) {
    try {
      logger.debug(`Trying ${type} search: ${query}`);
      const results = await searchGoogle(query);
      
      if (results.length === 0) {
        logger.debug(`No results found for ${type} search`);
        continue;
      }

      const match = results.find(result => isValidLinkedInCompanyUrl(result.link));
      
      if (match) {
        const cleanUrl = match.link.split('?')[0].replace(/\/$/, '');
        logger.success(`Found LinkedIn URL for ${name || cleanDomain} using ${type} search: ${cleanUrl}`);
        return cleanUrl;
      }
      
      logger.debug(`No valid LinkedIn company page found in ${type} search results`);
    } catch (error) {
      logger.warn(`${type} search failed for ${name || cleanDomain}: ${error.message}`);
    }
  }

  logger.warn(`No LinkedIn page found for ${name || cleanDomain} (${website}) after trying all search variations`);
  return null;
}
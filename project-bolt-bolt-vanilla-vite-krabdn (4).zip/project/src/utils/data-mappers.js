import { logger } from './logger';

export function mapEmployeeData(profile) {
  try {
    if (!profile) {
      throw new Error('No profile data provided');
    }

    // Extract LinkedIn ID from various possible sources
    const linkedinId = profile.id || 
                      profile.profile_id ||
                      profile.public_id ||
                      profile.member_urn?.split(':').pop() ||
                      profile.linkedin_url?.split('/in/')[1]?.split('?')[0] ||
                      profile.public_identifier;

    if (!linkedinId) {
      throw new Error('No LinkedIn ID found in profile data');
    }

    // Map positions and ensure company IDs are present
    const currentPositions = mapPositions(profile.current_positions, true);
    const workExperience = mapPositions(profile.work_experience || [], false);

    // Ensure we have at least basic name components
    const firstName = profile.first_name || profile.name?.split(' ')[0] || '';
    const lastName = profile.last_name || profile.name?.split(' ').slice(1).join(' ') || '';
    const fullName = profile.full_name || profile.name || `${firstName} ${lastName}`.trim();

    return {
      linkedin_id: linkedinId,
      first_name: firstName,
      last_name: lastName,
      full_name: fullName,
      headline: profile.headline,
      location: profile.location,
      industry: profile.industry,
      linkedin_url: profile.linkedin_url || profile.public_profile_url || profile.profile_url,
      profile_image_url: profile.profile_picture_url || profile.profile_image_url,
      profile_picture_url_large: profile.profile_picture_url_large,
      current_positions: currentPositions,
      work_experience: workExperience,
      education: mapEducation(profile.education || [])
    };
  } catch (error) {
    logger.error(`Failed to map employee data: ${error.message}`);
    return null;
  }
}

function mapPositions(positions, isCurrent = false) {
  if (!Array.isArray(positions)) {
    return [];
  }

  return positions.map(pos => {
    // Extract company ID from various possible sources
    const companyId = extractCompanyId(pos);

    // Clean up company name
    const company = pos.company || pos.companyName || pos.company_name;

    // Clean up role/title
    const role = pos.role || pos.title || pos.position;

    return {
      company,
      company_id: companyId,
      role,
      description: pos.description,
      location: pos.location,
      industry: pos.industry,
      start: normalizeDate(pos.start || pos.startDate || pos.date_range?.start),
      end: normalizeDate(pos.end || pos.endDate || pos.date_range?.end),
      is_current: isCurrent || (!pos.end && !pos.endDate && !pos.date_range?.end)
    };
  }).filter(pos => pos.company && pos.role);
}

function extractCompanyId(position) {
  // Try various possible sources for company ID
  const id = position.company_id || 
             position.companyId ||
             position.company_linkedin_id;
             
  if (id) return id.toString();

  // Try extracting from LinkedIn URL
  const url = position.company_linkedin_url || position.companyUrl;
  if (url?.includes('/company/')) {
    const matches = url.match(/company\/(\d+)/);
    if (matches?.[1]) return matches[1];
  }

  return null;
}

function mapEducation(education) {
  if (!Array.isArray(education)) {
    return [];
  }

  return education.map(edu => ({
    degree: edu.degree,
    school: edu.school || edu.schoolName,
    school_id: edu.school_id || edu.schoolId,
    start: normalizeDate(edu.start || edu.startDate),
    end: normalizeDate(edu.end || edu.endDate)
  })).filter(edu => edu.school);
}

function normalizeDate(date) {
  if (!date) return null;
  if (typeof date === 'object') {
    return {
      year: date.year || null,
      month: date.month || null
    };
  }
  return null;
}

export function mapSearchMetadata(searchData) {
  return {
    batch: searchData.batchNumber,
    search_type: searchData.type,
    companies: searchData.companies,
    url: searchData.url,
    timestamp: new Date().toISOString()
  };
}
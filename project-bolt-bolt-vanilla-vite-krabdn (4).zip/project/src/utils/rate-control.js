import { logger } from './logger.js';

const addJitter = (delay) => {
  const jitter = Math.random() * 1000 - 500; // ±500ms
  return Math.max(0, delay + jitter);
};

export class RateController {
  constructor(options = {}) {
    this.baseDelay = options.baseDelay || 10000;  // 10 seconds
    this.maxDelay = options.maxDelay || 60000;    // 60 seconds
    this.maxRetries = options.maxRetries || 3;
    this.queue = [];
    this.processing = false;
    this.lastRequestTime = Date.now();
  }

  async enqueue(operation) {
    return new Promise((resolve, reject) => {
      this.queue.push({
        operation,
        resolve,
        reject,
        attempts: 0,
        delay: this.baseDelay
      });
      
      if (!this.processing) {
        this.processQueue();
      }
    });
  }

  async processQueue() {
    if (this.processing || this.queue.length === 0) return;
    
    this.processing = true;
    const item = this.queue[0];

    try {
      // Ensure minimum delay between requests
      const timeSinceLastRequest = Date.now() - this.lastRequestTime;
      if (timeSinceLastRequest < item.delay) {
        const waitTime = item.delay - timeSinceLastRequest;
        logger.info(`Waiting ${Math.round(waitTime/1000)}s before next request...`);
        await new Promise(resolve => setTimeout(resolve, waitTime));
      }

      const result = await this.executeWithRetry(item);
      this.queue.shift();
      item.resolve(result);
    } catch (error) {
      this.queue.shift();
      item.reject(error);
    } finally {
      this.processing = false;
      if (this.queue.length > 0) {
        this.processQueue();
      }
    }
  }

  async executeWithRetry(item) {
    while (item.attempts < this.maxRetries) {
      try {
        this.lastRequestTime = Date.now();
        const result = await item.operation();
        
        if (item.attempts > 0) {
          logger.success(`Request succeeded after ${item.attempts + 1} attempts`);
        }
        
        return result;
      } catch (error) {
        item.attempts++;
        
        if (error.response?.status === 502 || error.response?.status === 429) {
          if (item.attempts < this.maxRetries) {
            // Exponential backoff
            item.delay = Math.min(item.delay * 2, this.maxDelay);
            const waitTime = addJitter(item.delay);
            
            logger.warn(
              `Request failed with ${error.response.status} (attempt ${item.attempts}/${this.maxRetries}), ` +
              `waiting ${Math.round(waitTime/1000)}s before retry...`
            );
            
            await new Promise(resolve => setTimeout(resolve, waitTime));
            continue;
          }
        }
        
        throw error;
      }
    }
    
    throw new Error(`Failed after ${this.maxRetries} attempts`);
  }
}
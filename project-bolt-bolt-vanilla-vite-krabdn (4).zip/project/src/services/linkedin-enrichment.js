import axios from 'axios';
import { config } from '../config/api-config.js';
import { logger } from '../utils/logger.js';
import { RateController } from '../utils/rate-control.js';
import { storeCompanyData } from './database/company.js';

const rateController = new RateController({
  baseDelay: 10000,
  maxDelay: 60000,
  maxRetries: 3
});

function normalizeLinkedInUrl(url) {
  try {
    const urlObj = new URL(url);
    let normalized = urlObj.origin + urlObj.pathname.replace(/\/$/, '');
    normalized = normalized.replace(/^https?:\/\/[^/]+/, 'https://www.linkedin.com');
    return normalized;
  } catch (error) {
    throw new Error(`Invalid LinkedIn URL: ${url}`);
  }
}

function mapCompanyData(apiResponse) {
  const { entry, data } = apiResponse;
  if (!data) return null;

  // Extract headquarters data
  const headquarters = data.headquarter ? {
    country: data.headquarter.country,
    city: data.headquarter.city,
    region: data.headquarter.geographicArea,
    address: data.headquarter.line1,
    postalCode: data.headquarter.postalCode
  } : null;

  // Map the company data
  return {
    linkedin_id: data.companyId?.toString(),
    name: data.companyName,
    website: data.websiteUrl,
    linkedin_url: entry,
    industry: data.industry,
    employee_count: data.employeeCount || 0,
    description: data.description,
    headquarters: headquarters ? JSON.stringify(headquarters) : null,
    specialties: Array.isArray(data.specialities) ? data.specialities : [],
    founded: data.foundedOn,
    tagline: data.tagline,
    follower_count: data.followerCount || 0,
    locations: Array.isArray(data.locations) ? 
      data.locations.map(loc => ({
        country: loc.country,
        city: loc.city,
        region: loc.geographicArea,
        address: loc.line1,
        postalCode: loc.postalCode
      })) : []
  };
}

export async function getCompanyDataBatch(linkedInPages) {
  try {
    if (!Array.isArray(linkedInPages) || linkedInPages.length === 0) {
      throw new Error('No LinkedIn pages provided');
    }

    // Split URLs into batches of 25
    const batches = [];
    for (let i = 0; i < linkedInPages.length; i += 25) {
      batches.push(linkedInPages.slice(i, i + 25));
    }

    logger.info(`Processing ${linkedInPages.length} URLs in ${batches.length} batches of up to 25`);

    const results = [];
    for (let i = 0; i < batches.length; i++) {
      const batch = batches[i];
      logger.info(`Processing batch ${i + 1}/${batches.length} (${batch.length} URLs)`);
      
      try {
        const batchResults = await processUrlBatch(batch);
        results.push(...batchResults);
        logger.success(`Batch ${i + 1} complete: ${batchResults.length}/${batch.length} companies processed`);
      } catch (error) {
        logger.error(`Batch ${i + 1} failed: ${error.message}`);
        continue;
      }
    }

    return results;
  } catch (error) {
    logger.error('Company data batch processing failed:', error);
    throw error;
  }
}

async function processUrlBatch(pages) {
  const normalizedUrls = pages.map(page => {
    try {
      return normalizeLinkedInUrl(page.linkedInUrl);
    } catch (error) {
      logger.warn(`Invalid URL skipped: ${page.linkedInUrl}`);
      return null;
    }
  }).filter(Boolean);

  if (normalizedUrls.length === 0) {
    return [];
  }

  logger.info(`Sending batch request for ${normalizedUrls.length} URLs`);

  return rateController.enqueue(async () => {
    try {
      const response = await axios.post(
        config.rapidApi.baseUrl,
        { links: normalizedUrls },
        {
          headers: {
            'Content-Type': 'application/json',
            'X-RapidAPI-Key': config.rapidApi.apiKey,
            'X-RapidAPI-Host': config.rapidApi.host
          },
          timeout: 30000
        }
      );

      if (!response.data?.success) {
        throw new Error(`API error: ${response.data?.message || 'Unknown error'}`);
      }

      if (!Array.isArray(response.data.data)) {
        throw new Error('Invalid response format from API');
      }

      const mappedCompanies = response.data.data
        .filter(item => item?.entry && item?.data)
        .map(mapCompanyData)
        .filter(Boolean);

      // Store each company in database
      const results = [];
      for (const company of mappedCompanies) {
        const storedCompany = await storeCompanyData(company);
        if (storedCompany) {
          results.push(storedCompany);
        }
      }

      logger.success(`Successfully processed ${results.length}/${normalizedUrls.length} companies in batch`);
      return results;
    } catch (error) {
      if (error.response?.data) {
        logger.error('API Error Response:', error.response.data);
      }
      throw error;
    }
  });
}
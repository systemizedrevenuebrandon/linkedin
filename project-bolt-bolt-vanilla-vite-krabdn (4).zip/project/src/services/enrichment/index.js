import { enrichProfiles } from './profile-enricher';
import { cleanNames } from './name-cleaner';
import { linkCompanies } from './company-linker';
import { logger } from '../../utils/logger';

export async function runEnrichmentWorkflow() {
  try {
    logger.info('Starting enrichment workflow');

    // Step 1: Enrich profiles with work experience and education
    logger.info('Step 1: Enriching profiles');
    const enrichedProfiles = await enrichProfiles();
    
    if (enrichedProfiles.length > 0) {
      // Step 2: Clean names
      logger.info('Step 2: Cleaning names');
      await cleanNames();

      // Step 3: Link companies and employees
      logger.info('Step 3: Linking companies');
      await linkCompanies();

      logger.success('Enrichment workflow completed successfully');
    } else {
      logger.info('No profiles needed enrichment, workflow complete');
    }
  } catch (error) {
    logger.error('Enrichment workflow failed:', error);
    throw error;
  }
}
export function cleanCompanyName(name) {
  if (!name) return '';

  // Remove common legal suffixes
  const suffixes = [
    'LLC',
    'LLC.',
    'Inc',
    'Inc.',
    'INC',
    'INC.',
    'Corporation',
    'Corp',
    'Corp.',
    'Ltd',
    'Ltd.',
    'Limited',
    'Company',
    'L.L.C.',
    'L.L.C',
    'LTD.',
    'LTD',
    'CORP.',
    'CORPORATION',
    'CO.',
    'CO',
    'INCORPORATED',
    'INC.'
  ];

  let cleanName = name.trim();
  
  // Remove legal suffixes
  const suffixPattern = new RegExp(`\\s*[,.]?\\s*(${suffixes.join('|')})\\b\\.?\\s*$`, 'gi');
  cleanName = cleanName.replace(suffixPattern, '');
  
  // Remove quotes and extra punctuation
  cleanName = cleanName.replace(/["']/g, '');
  cleanName = cleanName.replace(/\.+$/, '');
  
  // Remove extra spaces and standardize
  cleanName = cleanName.replace(/\s+/g, ' ').trim();
  
  return cleanName;
}
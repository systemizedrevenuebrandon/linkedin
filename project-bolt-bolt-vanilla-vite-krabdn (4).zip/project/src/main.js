import './style.css';
import { processCompanies } from './services/company-processor.js';
import { generateSalesNavUrls } from './services/sales-navigator.js';
import { logger } from './utils/logger.js';
import { parseCSV } from './utils/csv-parser.js';

document.querySelector('#app').innerHTML = `
  <div class="container">
    <div class="header">
      <h1>Website Processor</h1>
      <p>Upload a CSV file or enter website URLs and job titles to generate Sales Navigator search URLs</p>
    </div>
    
    <div class="input-group">
      <label for="csv">Upload CSV file (with website and company name columns):</label>
      <input type="file" id="csv" accept=".csv" class="file-input" />
    </div>
    
    <div class="input-group">
      <label for="websites">Or enter websites manually (one per line):</label>
      <textarea 
        id="websites" 
        placeholder="example.com
another-example.com
test-company.com"
      ></textarea>
    </div>

    <div class="input-group">
      <label for="titles">Job Titles (one per line):</label>
      <textarea 
        id="titles" 
        placeholder="CEO
CTO
VP Engineering"
      ></textarea>
    </div>
    
    <div class="button-group">
      <button id="process">Process & Generate URLs</button>
      <button id="clear" class="secondary">Clear All</button>
    </div>
    
    <div class="progress">
      <div class="progress-bar"></div>
    </div>
    
    <div id="summary" class="summary"></div>
    <div id="urls" class="urls"></div>
  </div>
`;

const summaryDiv = document.querySelector('#summary');
const urlsDiv = document.querySelector('#urls');
const processButton = document.querySelector('#process');
const clearButton = document.querySelector('#clear');
const websitesInput = document.querySelector('#websites');
const titlesInput = document.querySelector('#titles');
const csvInput = document.querySelector('#csv');
const progress = document.querySelector('.progress');
const progressBar = document.querySelector('.progress-bar');

let processedCount = 0;
let totalWebsites = 0;
let companies = [];

logger.setCallbacks({
  onProgress: () => {
    processedCount++;
    const percentage = (processedCount / totalWebsites) * 100;
    progressBar.style.width = `${percentage}%`;
  },
  onComplete: (stats) => {
    if (!stats) return;
    
    summaryDiv.innerHTML = `
      <div class="summary-item">
        <span>Total Websites:</span> ${stats.total}
      </div>
      <div class="summary-item">
        <span>Successfully Processed:</span> ${stats.successful}
      </div>
      <div class="summary-item">
        <span>Failed:</span> ${stats.failed}
      </div>
    `;
  },
  onSalesNavUrl: (url) => {
    if (!url) return;
    
    const urlElement = document.createElement('div');
    urlElement.className = 'url-item';
    urlElement.textContent = url;
    urlElement.addEventListener('click', () => {
      navigator.clipboard.writeText(url);
      urlElement.style.backgroundColor = '#3a3a3a';
      setTimeout(() => {
        urlElement.style.backgroundColor = '';
      }, 200);
    });
    urlsDiv.appendChild(urlElement);
  }
});

csvInput.addEventListener('change', async (event) => {
  const file = event.target.files[0];
  if (!file) return;
  
  try {
    companies = await parseCSV(file);
    websitesInput.value = companies.map(c => c.website).join('\n');
    websitesInput.disabled = true;
  } catch (error) {
    logger.error(error.message);
  }
});

clearButton.addEventListener('click', () => {
  summaryDiv.innerHTML = '';
  urlsDiv.innerHTML = '';
  websitesInput.value = '';
  titlesInput.value = '';
  csvInput.value = '';
  websitesInput.disabled = false;
  companies = [];
  progress.classList.remove('active');
  progressBar.style.width = '0%';
  processedCount = 0;
});

processButton.addEventListener('click', async () => {
  const websites = websitesInput.value
    .split('\n')
    .map(url => url.trim())
    .filter(url => url);

  const titles = titlesInput.value
    .split('\n')
    .map(title => title.trim())
    .filter(title => title);

  if (websites.length === 0) {
    await logger.error('Please enter at least one website or upload a CSV file');
    return;
  }

  processButton.disabled = true;
  clearButton.disabled = true;
  summaryDiv.innerHTML = '';
  urlsDiv.innerHTML = '';
  progress.classList.add('active');
  processedCount = 0;
  totalWebsites = websites.length;
  
  try {
    const websitesWithNames = websites.map(website => {
      const company = companies.find(c => c.website === website);
      return {
        website,
        name: company?.name || null
      };
    });

    const result = await processCompanies(websitesWithNames);
    
    if (result.results.length > 0) {
      const companyIds = result.results
        .filter(company => company.companyId)
        .map(company => company.companyId);

      if (companyIds.length > 0) {
        const salesNavUrls = generateSalesNavUrls(companyIds, titles);
        salesNavUrls.forEach(url => {
          logger.success('Generated Sales Navigator URL:', url);
        });
      }
    }
  } catch (error) {
    await logger.error(`Processing failed: ${error.message}`);
  } finally {
    processButton.disabled = false;
    clearButton.disabled = false;
  }
});
import axios from 'axios';
import { logger } from '../utils/logger.js';
import { RateController } from '../utils/rate-control.js';
import { config } from '../config/api-config.js';

const rateController = new RateController({
  baseDelay: 2000,
  maxDelay: 30000,
  maxRetries: 3,
  maxRequestsPerWindow: 5,
  windowSize: 60000
});

/**
 * Fetches employee data from a Sales Navigator URL
 * @param {string} url - Sales Navigator search URL
 * @param {number} limit - Maximum number of employees to fetch
 * @returns {Promise<Array>} Array of employee data
 */
export async function fetchEmployeeData(url, limit = 2500) {
  return rateController.enqueue(async () => {
    try {
      logger.info(`Fetching employee data for URL: ${url}`);
      
      const response = await axios.post(
        'https://fresh-linkedin-profile-data.p.rapidapi.com/search-employees-by-sales-nav-url',
        {
          url,
          limit
        },
        {
          headers: {
            'Content-Type': 'application/json',
            'X-RapidAPI-Key': config.rapidApi.apiKey,
            'X-RapidAPI-Host': 'fresh-linkedin-profile-data.p.rapidapi.com'
          }
        }
      );

      if (!response.data?.results) {
        throw new Error('Invalid response format from API');
      }

      logger.success(`Found ${response.data.results.length} employees`);
      return response.data.results;
    } catch (error) {
      logger.error(`Failed to fetch employee data: ${error.message}`);
      throw error;
    }
  });
}

/**
 * Processes multiple Sales Navigator URLs to fetch employee data
 * @param {Array} urls - Array of Sales Navigator URL objects
 * @param {number} limit - Maximum employees per URL
 * @returns {Promise<Object>} Combined results
 */
export async function processEmployeeUrls(urls, limit = 2500) {
  try {
    if (!Array.isArray(urls) || urls.length === 0) {
      throw new Error('No URLs provided');
    }

    logger.info(`Processing ${urls.length} Sales Navigator URLs`);
    
    const results = [];
    const failed = [];

    for (const urlData of urls) {
      try {
        const employees = await fetchEmployeeData(urlData.url, limit);
        results.push({
          ...urlData,
          employees,
          employeeCount: employees.length
        });
        logger.success(`Processed URL batch ${urlData.batchNumber}: Found ${employees.length} employees`);
      } catch (error) {
        failed.push({
          ...urlData,
          error: error.message
        });
        logger.error(`Failed to process URL batch ${urlData.batchNumber}: ${error.message}`);
      }
    }

    return {
      results,
      failed,
      totalEmployees: results.reduce((sum, r) => sum + r.employeeCount, 0),
      processedUrls: results.length,
      failedUrls: failed.length
    };
  } catch (error) {
    logger.error('Employee data processing failed:', error);
    throw error;
  }
}
import { supabase } from '../../config/supabase';
import { logger } from '../../utils/logger';

export async function storeSearchResult(searchData, employeeCount) {
  try {
    const { error } = await supabase
      .from('search_results')
      .insert({
        batch_number: searchData.batchNumber,
        search_type: searchData.type,
        search_url: searchData.url,
        companies: searchData.companies,
        employee_count: employeeCount
      });

    if (error) throw error;
    logger.success(`Stored search result for batch ${searchData.batchNumber}`);
  } catch (error) {
    logger.error(`Failed to store search result: ${error.message}`);
  }
}
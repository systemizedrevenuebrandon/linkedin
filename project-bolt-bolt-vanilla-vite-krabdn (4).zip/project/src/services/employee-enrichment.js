import axios from 'axios';
import { config } from '../config/api-config.js';
import { logger } from '../utils/logger.js';
import { supabase } from '../config/supabase.js';
import { RateController } from '../utils/rate-control.js';

const rateController = new RateController({
  baseDelay: 5000,
  maxDelay: 60000,
  maxRetries: 5,
  maxRequestsPerWindow: 2,
  windowSize: 60000
});

async function findEmployeesNeedingEnrichment() {
  try {
    const { data, error } = await supabase
      .from('employees')
      .select('linkedin_id, linkedin_url')
      .eq('work_experience', '[]')
      .not('linkedin_url', 'is', null)
      .order('created_at', { ascending: false })
      .limit(100);

    if (error) throw error;

    // Filter out invalid LinkedIn URLs
    return data.filter(emp => 
      emp.linkedin_url?.includes('linkedin.com/in/') && 
      !emp.linkedin_url.includes('?')
    );
  } catch (error) {
    logger.error('Failed to find employees needing enrichment:', error);
    throw error;
  }
}

async function enrichEmployeeProfiles(batch) {
  try {
    const linkedinUrls = batch.map(emp => emp.linkedin_url);
    logger.info(`Enriching batch of ${linkedinUrls.length} profiles`);
    
    const response = await axios.post(
      'https://linkedin-bulk-data-scraper.p.rapidapi.com/profiles',
      { links: linkedinUrls },
      {
        headers: {
          'Content-Type': 'application/json',
          'X-RapidAPI-Key': config.rapidApi.apiKey,
          'X-RapidAPI-Host': 'linkedin-bulk-data-scraper.p.rapidapi.com'
        }
      }
    );

    if (!response.data?.data) {
      throw new Error('Invalid response from enrichment API');
    }

    return response.data.data
      .filter(item => item?.data)
      .map(item => ({
        linkedin_url: item.entry,
        work_experience: item.data.experiences?.map(exp => ({
          company: exp.subtitle,
          company_id: exp.companyId,
          role: exp.title,
          industry: exp.industry,
          start: exp.start,
          end: exp.end
        })) || [],
        current_positions: item.data.experiences?.filter(exp => !exp.end).map(exp => ({
          company: exp.subtitle,
          company_id: exp.companyId,
          role: exp.title,
          description: exp.description,
          location: exp.location,
          start: exp.start,
          end: exp.end
        })) || [],
        education: item.data.educations?.map(edu => ({
          degree: edu.degree,
          school: edu.school,
          school_id: edu.schoolId,
          start: edu.start,
          end: edu.end
        })) || []
      }));
  } catch (error) {
    if (error.response?.status === 503) {
      logger.warn('RapidAPI service temporarily unavailable, will retry in 30s...');
      await new Promise(resolve => setTimeout(resolve, 30000));
      throw error;
    }
    throw error;
  }
}

async function updateEmployeeInDatabase(enrichedData) {
  try {
    const { error } = await supabase
      .from('employees')
      .update({
        work_experience: enrichedData.work_experience,
        current_positions: enrichedData.current_positions,
        education: enrichedData.education,
        updated_at: new Date().toISOString()
      })
      .eq('linkedin_url', enrichedData.linkedin_url);

    if (error) throw error;
    logger.success(`Updated employee ${enrichedData.linkedin_url} with enriched data`);
    return true;
  } catch (error) {
    logger.error(`Failed to update employee ${enrichedData.linkedin_url}: ${error.message}`);
    return false;
  }
}

export async function enrichNewEmployees() {
  try {
    const employees = await findEmployeesNeedingEnrichment();
    if (!employees?.length) {
      logger.info('No new employees to enrich');
      return [];
    }

    logger.info(`Found ${employees.length} employees to enrich`);

    // Process in batches of 25
    const batchSize = 25;
    const batches = [];
    for (let i = 0; i < employees.length; i += batchSize) {
      batches.push(employees.slice(i, i + batchSize));
    }

    const results = [];
    for (let i = 0; i < batches.length; i++) {
      const batch = batches[i];
      logger.info(`Processing batch ${i + 1}/${batches.length} (${batch.length} profiles)`);

      try {
        if (i > 0) {
          logger.info('Waiting 10s before next batch...');
          await new Promise(resolve => setTimeout(resolve, 10000));
        }

        const enrichedProfiles = await rateController.enqueue(() => 
          enrichEmployeeProfiles(batch)
        );

        for (const profile of enrichedProfiles) {
          const success = await updateEmployeeInDatabase(profile);
          results.push({
            linkedin_url: profile.linkedin_url,
            success
          });
        }
      } catch (error) {
        logger.error(`Failed to process batch ${i + 1}: ${error.message}`);
        batch.forEach(emp => {
          results.push({
            linkedin_url: emp.linkedin_url,
            success: false,
            error: error.message
          });
        });
      }
    }

    const successful = results.filter(r => r.success).length;
    logger.success(`Enriched ${successful}/${employees.length} employee profiles`);
    return results;
  } catch (error) {
    logger.error('Employee enrichment process failed:', error);
    throw error;
  }
}
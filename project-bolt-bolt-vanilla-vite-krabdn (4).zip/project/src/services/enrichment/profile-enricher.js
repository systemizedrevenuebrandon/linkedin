import axios from 'axios';
import { config } from '../../config/api-config';
import { logger } from '../../utils/logger';
import { RateController } from '../../utils/rate-control';
import { findEmployeesNeedingEnrichment, updateEnrichedProfile } from '../database';

const rateController = new RateController({
  baseDelay: 2000,
  maxDelay: 30000,
  maxRetries: 3,
  maxRequestsPerWindow: 5,
  windowSize: 60000
});

async function enrichProfileBatch(linkedinUrls) {
  try {
    logger.info(`Enriching batch of ${linkedinUrls.length} profiles`);
    
    const response = await axios.post(
      config.rapidApi.profilesUrl,
      { links: linkedinUrls },
      {
        headers: {
          'Content-Type': 'application/json',
          'X-RapidAPI-Key': config.rapidApi.apiKey,
          'X-RapidAPI-Host': config.rapidApi.host
        }
      }
    );

    if (!response.data?.data) {
      throw new Error('Invalid response from enrichment API');
    }

    return response.data.data
      .filter(item => item?.data)
      .map(item => ({
        linkedin_url: item.entry,
        work_experience: mapExperiences(item.data.experiences),
        current_positions: mapCurrentPositions(item.data.experiences),
        education: mapEducation(item.data.educations)
      }));
  } catch (error) {
    logger.error('Profile enrichment failed:', error);
    throw error;
  }
}

function mapExperiences(experiences) {
  if (!Array.isArray(experiences)) return [];
  return experiences.map(exp => ({
    company: exp.subtitle,
    company_id: exp.companyId,
    company_link: exp.companyLink1,
    role: exp.title,
    description: exp.description,
    location: exp.location,
    start: parseDate(exp.caption, 'start'),
    end: parseDate(exp.caption, 'end'),
    duration: exp.caption,
    breakdown: exp.breakdown,
    subComponents: exp.subComponents
  }));
}

function mapCurrentPositions(experiences) {
  if (!Array.isArray(experiences)) return [];
  return experiences
    .filter(exp => !parseDate(exp.caption, 'end'))
    .map(exp => ({
      company: exp.subtitle,
      company_id: exp.companyId,
      company_link: exp.companyLink1,
      role: exp.title,
      description: exp.description,
      location: exp.location,
      start: parseDate(exp.caption, 'start'),
      duration: exp.caption,
      breakdown: exp.breakdown,
      subComponents: exp.subComponents
    }));
}

function mapEducation(educations) {
  if (!Array.isArray(educations)) return [];
  return educations.map(edu => ({
    degree: edu.title,
    school: edu.subtitle,
    school_id: edu.schoolId,
    school_link: edu.companyLink1,
    start: parseDate(edu.caption, 'start'),
    end: parseDate(edu.caption, 'end'),
    duration: edu.caption,
    description: edu.description,
    subComponents: edu.subComponents
  }));
}

function parseDate(caption, type) {
  if (!caption) return null;
  
  // Example: "Aug 2006 - Present · 17 yrs 7 mos"
  const parts = caption.split(' - ');
  if (parts.length !== 2) return null;

  const [start, end] = parts;
  const startParts = start.split(' ');
  const endParts = end.split(' ·')[0].trim();

  if (type === 'start' && startParts.length === 2) {
    return {
      month: startParts[0],
      year: parseInt(startParts[1])
    };
  }

  if (type === 'end' && endParts !== 'Present') {
    const endDateParts = endParts.split(' ');
    if (endDateParts.length === 2) {
      return {
        month: endDateParts[0],
        year: parseInt(endDateParts[1])
      };
    }
  }

  return null;
}

export async function enrichProfiles() {
  try {
    const employees = await findEmployeesNeedingEnrichment();
    if (!employees?.length) {
      logger.info('No profiles need enrichment');
      return [];
    }

    logger.info(`Found ${employees.length} profiles to enrich`);

    // Process in batches of 25
    const batchSize = 25;
    const results = [];

    for (let i = 0; i < employees.length; i += batchSize) {
      const batch = employees.slice(i, i + batchSize);
      const linkedinUrls = batch.map(emp => emp.linkedin_url);

      try {
        const enrichedProfiles = await rateController.enqueue(() => 
          enrichProfileBatch(linkedinUrls)
        );

        for (const profile of enrichedProfiles) {
          const success = await updateEnrichedProfile(profile);
          results.push({
            linkedin_url: profile.linkedin_url,
            success
          });
        }

        if (i + batchSize < employees.length) {
          logger.info('Waiting before next batch...');
          await new Promise(resolve => setTimeout(resolve, 5000));
        }
      } catch (error) {
        logger.error(`Failed to process batch: ${error.message}`);
        batch.forEach(emp => {
          results.push({
            linkedin_url: emp.linkedin_url,
            success: false,
            error: error.message
          });
        });
      }
    }

    const successful = results.filter(r => r.success).length;
    logger.success(`Enriched ${successful}/${employees.length} profiles`);
    return results;
  } catch (error) {
    logger.error('Profile enrichment process failed:', error);
    throw error;
  }
}
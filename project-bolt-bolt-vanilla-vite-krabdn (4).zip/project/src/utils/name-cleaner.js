import OpenAI from 'openai';
import { config } from '../config/api-config';
import { logger } from './logger';

const openai = new OpenAI({
  apiKey: config.openai.apiKey,
  dangerouslyAllowBrowser: true
});

export async function cleanName(name) {
  if (!name) return null;
  
  try {
    const prompt = `Clean this LinkedIn profile name by removing unnecessary information such as pronouns, titles, degrees, certifications, or middle names. Keep only the first name and last name.

Examples:
- "Sarah Elizabeth Johnson (She/Her) - Tech Lead" -> "Sarah Johnson"
- "Dr. Michael Robert Smith, PhD, MBA" -> "Michael Smith"
- "James William Henry Thompson III" -> "James Thompson"
- "John-Paul Smith-Jones, CFA" -> "John Smith"
- "Maria A. Rodriguez-Garcia, MD" -> "Maria Rodriguez"
- "Robert (Bob) Williams Jr." -> "Robert Williams"
- "Winston Yan, MD PhD" -> "Winston Yan"

Name to clean: "${name}"

Return only the cleaned name without any explanation.`;

    const completion = await openai.chat.completions.create({
      model: config.openai.model,
      messages: [
        {
          role: "system",
          content: "You are a name cleaning expert. Return only the cleaned name without any explanation."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      temperature: 0.1,
      max_tokens: 100
    });

    const cleanedName = completion.choices[0].message.content.trim();
    const parts = cleanedName.split(' ').filter(Boolean);

    if (parts.length < 2) {
      throw new Error(`Invalid cleaned name format: "${cleanedName}"`);
    }

    return {
      first_name: parts[0],
      last_name: parts.slice(1).join(' '),
      full_name: cleanedName
    };
  } catch (error) {
    logger.error(`Failed to clean name "${name}": ${error.message}`);
    return {
      first_name: name.split(' ')[0],
      last_name: name.split(' ').slice(1).join(' '),
      full_name: name
    };
  }
}
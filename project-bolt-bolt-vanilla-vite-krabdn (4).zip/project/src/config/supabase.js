import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://vuvlbzeauadlitbhsszr.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZ1dmxiemVhdWFkbGl0Ymhzc3pyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzMyMzUyNjQsImV4cCI6MjA0ODgxMTI2NH0.0OD-ciP0AN4l2GuBEcKuFuBPlO-cKss-KGR1gPWqssI';

export const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: {
    persistSession: false
  }
});
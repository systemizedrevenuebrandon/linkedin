import React, { useState, useCallback, useEffect } from 'react'
import { Button } from './components/ui/button'
import { Textarea } from './components/ui/textarea'
import { Progress } from './components/ui/progress'
import { ScrollArea } from './components/ui/scroll-area'
import { Upload, X, AlertCircle, Link as LinkIcon, Copy, Download } from 'lucide-react'
import { processCompanies } from './services/company-processor'
import { processEmployeeUrls } from './services/employee-job-processor'
import { logger } from './utils/logger'
import { parseCSV } from './utils/csv-parser'
import { downloadCSV } from './utils/csv-generator'
import { initializeDatabase } from './services/database-init'

export default function App() {
  const [companies, setCompanies] = useState([])
  const [websites, setWebsites] = useState('')
  const [titles, setTitles] = useState('')
  const [progress, setProgress] = useState(0)
  const [isProcessing, setIsProcessing] = useState(false)
  const [results, setResults] = useState(null)
  const [errors, setErrors] = useState([])
  const [salesNavUrls, setSalesNavUrls] = useState([])
  const [employeeResults, setEmployeeResults] = useState(null)
  const [isProcessingEmployees, setIsProcessingEmployees] = useState(false)
  const [isDatabaseInitialized, setIsDatabaseInitialized] = useState(false)

  useEffect(() => {
    const setupDatabase = async () => {
      try {
        await initializeDatabase()
        setIsDatabaseInitialized(true)
      } catch (error) {
        setErrors(prev => [...prev, `Database initialization failed: ${error.message}`])
      }
    }
    setupDatabase()
  }, [])

  const handleFileUpload = async (event) => {
    const file = event.target.files[0]
    if (!file) return

    try {
      const parsedCompanies = await parseCSV(file)
      setCompanies(parsedCompanies)
      setWebsites(parsedCompanies.map(c => c.website).join('\n'))
      setErrors([])
    } catch (error) {
      setErrors([error.message])
    }
  }

  const handleProcess = async () => {
    if (!isDatabaseInitialized) {
      setErrors(['Please wait for database initialization to complete'])
      return
    }

    const websiteList = websites
      .split('\n')
      .map(url => url.trim())
      .filter(url => url)

    const titleList = titles
      .split('\n')
      .map(title => title.trim())
      .filter(title => title)

    if (websiteList.length === 0) {
      setErrors(['Please enter at least one website or upload a CSV file'])
      return
    }

    setIsProcessing(true)
    setProgress(0)
    setResults(null)
    setSalesNavUrls([])
    setErrors([])
    setEmployeeResults(null)

    try {
      const websitesWithNames = websiteList.map(website => {
        const company = companies.find(c => c.website === website)
        return {
          website,
          name: company?.name || null
        }
      })

      const result = await processCompanies(websitesWithNames, titleList)
      setResults(result)
      
      if (result.salesNavUrls?.length > 0) {
        setSalesNavUrls(result.salesNavUrls)
        // Automatically start processing employees
        handleProcessEmployees(result.salesNavUrls)
      }

    } catch (error) {
      setErrors(prev => [...prev, error.message])
    } finally {
      setIsProcessing(false)
    }
  }

  const handleProcessEmployees = async (urls = salesNavUrls) => {
    if (!urls.length) return;

    setIsProcessingEmployees(true)
    try {
      const results = await processEmployeeUrls(urls)
      setEmployeeResults(results)
    } catch (error) {
      setErrors(prev => [...prev, error.message])
    } finally {
      setIsProcessingEmployees(false)
    }
  }

  const handleDownloadEmployees = () => {
    if (!employeeResults?.csvData) return;
    downloadCSV(employeeResults.csvData, 'employee_data.csv')
  }

  const handleClear = () => {
    setCompanies([])
    setWebsites('')
    setTitles('')
    setProgress(0)
    setResults(null)
    setSalesNavUrls([])
    setErrors([])
    setEmployeeResults(null)
  }

  const copyToClipboard = async (url, index) => {
    try {
      await navigator.clipboard.writeText(url)
      setSalesNavUrls(prev => prev.map((item, i) => 
        i === index ? { ...item, copied: true } : item
      ))
      setTimeout(() => {
        setSalesNavUrls(prev => prev.map((item, i) => 
          i === index ? { ...item, copied: false } : item
        ))
      }, 2000)
    } catch (error) {
      console.error('Failed to copy:', error)
    }
  }

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="container max-w-4xl">
        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Website Processor</h1>
            <p className="text-muted-foreground mt-2">
              Upload a CSV file or enter website URLs and job titles to generate Sales Navigator search URLs
            </p>
          </div>

          <div className="grid gap-6">
            <div className="space-y-2">
              <label className="text-sm font-medium">Upload CSV file</label>
              <div className="flex items-center gap-4">
                <Button
                  variant="outline"
                  className="w-[200px]"
                  onClick={() => document.getElementById('csv-upload').click()}
                >
                  <Upload className="mr-2 h-4 w-4" />
                  Choose File
                </Button>
                <input
                  id="csv-upload"
                  type="file"
                  accept=".csv"
                  className="hidden"
                  onChange={handleFileUpload}
                />
                {companies.length > 0 && (
                  <span className="text-sm text-muted-foreground">
                    {companies.length} companies loaded
                  </span>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Websites (one per line)</label>
              <Textarea
                value={websites}
                onChange={(e) => setWebsites(e.target.value)}
                placeholder="example.com&#10;another-example.com"
                className="min-h-[120px]"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Job Titles (one per line)</label>
              <Textarea
                value={titles}
                onChange={(e) => setTitles(e.target.value)}
                placeholder="CEO&#10;CTO&#10;VP Engineering"
                className="min-h-[120px]"
              />
            </div>

            <div className="flex gap-4">
              <Button
                onClick={handleProcess}
                disabled={isProcessing || !isDatabaseInitialized}
                className="w-[200px]"
              >
                {isProcessing ? 'Processing...' : 'Process & Generate URLs'}
              </Button>
              <Button
                variant="outline"
                onClick={handleClear}
                disabled={isProcessing}
              >
                Clear All
              </Button>
            </div>

            {isProcessing && (
              <Progress value={progress} className="w-full" />
            )}

            {errors.length > 0 && (
              <div className="rounded-lg border border-destructive p-4 text-destructive">
                <div className="flex items-center gap-2">
                  <AlertCircle className="h-4 w-4" />
                  <span className="font-medium">Errors occurred:</span>
                </div>
                <ul className="list-disc list-inside mt-2 space-y-1">
                  {errors.map((error, index) => (
                    <li key={index} className="text-sm">{error}</li>
                  ))}
                </ul>
              </div>
            )}

            {results && (
              <div className="grid grid-cols-3 gap-4">
                <div className="rounded-lg border p-4 text-center">
                  <div className="text-2xl font-bold">{results.processedCount}</div>
                  <div className="text-sm text-muted-foreground">Total Processed</div>
                </div>
                <div className="rounded-lg border p-4 text-center">
                  <div className="text-2xl font-bold text-green-600">
                    {results.successCount}
                  </div>
                  <div className="text-sm text-muted-foreground">Successfully Enriched</div>
                </div>
                <div className="rounded-lg border p-4 text-center">
                  <div className="text-2xl font-bold text-blue-600">
                    {results.nameBasedCount}
                  </div>
                  <div className="text-sm text-muted-foreground">Name-Based Search</div>
                </div>
              </div>
            )}

            {salesNavUrls.length > 0 && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-medium">Sales Navigator URLs</h3>
                  <Button
                    onClick={() => handleProcessEmployees()}
                    disabled={isProcessingEmployees}
                  >
                    {isProcessingEmployees ? 'Processing...' : 'Process Employee Data'}
                  </Button>
                </div>
                <ScrollArea className="h-[400px] rounded-lg border p-4">
                  <div className="space-y-4">
                    {salesNavUrls.map((urlData, index) => (
                      <div
                        key={index}
                        className="rounded-lg border p-4 space-y-2 hover:bg-accent transition-colors"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <LinkIcon className="h-4 w-4 text-muted-foreground" />
                            <span className="font-medium">
                              {urlData.type === 'id-based' ? 'ID-Based Search' : 'Name-Based Search'}
                            </span>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => copyToClipboard(urlData.url, index)}
                          >
                            {urlData.copied ? (
                              <span className="text-green-600">Copied!</span>
                            ) : (
                              <Copy className="h-4 w-4" />
                            )}
                          </Button>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Batch {urlData.batchNumber} • {urlData.companyCount} companies
                        </div>
                        <div className="text-sm break-all">
                          <a
                            href={urlData.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:underline"
                          >
                            {urlData.url}
                          </a>
                        </div>
                        <div className="text-xs text-muted-foreground mt-2">
                          Companies: {urlData.companies.join(', ')}
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            )}

            {employeeResults && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-medium">Employee Data Results</h3>
                  <Button
                    onClick={handleDownloadEmployees}
                    disabled={!employeeResults.csvData?.length}
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Download CSV
                  </Button>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="rounded-lg border p-4 text-center">
                    <div className="text-2xl font-bold">{employeeResults.totalEmployees}</div>
                    <div className="text-sm text-muted-foreground">Total Employees</div>
                  </div>
                  <div className="rounded-lg border p-4 text-center">
                    <div className="text-2xl font-bold text-green-600">
                      {employeeResults.processedUrls}
                    </div>
                    <div className="text-sm text-muted-foreground">Processed URLs</div>
                  </div>
                  <div className="rounded-lg border p-4 text-center">
                    <div className="text-2xl font-bold text-red-600">
                      {employeeResults.failedUrls}
                    </div>
                    <div className="text-sm text-muted-foreground">Failed URLs</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
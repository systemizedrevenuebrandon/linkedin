/**
 * Splits an array into chunks of specified size
 * @param {Array} array - The array to split
 * @param {number} size - The maximum size of each chunk
 * @returns {Array} Array of chunks
 */
export function chunkArray(array, size) {
  return array.reduce((chunks, item, index) => {
    const chunkIndex = Math.floor(index / size);
    if (!chunks[chunkIndex]) {
      chunks[chunkIndex] = [];
    }
    chunks[chunkIndex].push(item);
    return chunks;
  }, []);
}

/**
 * Groups array items by a key
 * @param {Array} array - The array to group
 * @param {Function} keyFn - Function to generate the group key
 * @returns {Object} Grouped items
 */
export function groupBy(array, keyFn) {
  return array.reduce((groups, item) => {
    const key = keyFn(item);
    if (!groups[key]) {
      groups[key] = [];
    }
    groups[key].push(item);
    return groups;
  }, {});
}
import { findLinkedInCompanyPage } from './google-search.js';
import { getCompanyDataBatch } from './linkedin-enrichment.js';
import { generateSalesNavUrls } from './sales-navigator.js';
import { logger } from '../utils/logger.js';
import { validateInputs } from '../utils/input-validator.js';
import { extractCompanyNameFromUrl } from '../utils/url-validator.js';
import { checkWebsiteAvailability } from '../utils/website-checker.js';
import { RateController } from '../utils/rate-control.js';
import { storeCompanyData, storeSearchResult } from './database';

const processingController = new RateController({
  baseDelay: 1000,
  maxDelay: 16000,
  maxRetries: 2,
  maxRequestsPerWindow: 10,
  windowSize: 60000
});

export async function processCompanies(companies, titles = []) {
  try {
    if (!Array.isArray(companies)) {
      throw new Error('Input must be an array of company data');
    }

    const validCompanies = companies.filter(company => 
      company && 
      typeof company === 'object' && 
      company.website
    );

    if (validCompanies.length === 0) {
      throw new Error('No valid company data provided');
    }

    const websites = validCompanies.map(company => company.website);
    if (!validateInputs(websites)) {
      throw new Error('Invalid website URLs provided');
    }

    logger.info(`Starting to process ${validCompanies.length} companies`);
    
    const linkedInPages = [];
    const notFoundCompanies = [];
    const failed = [];

    await Promise.all(
      validCompanies.map(company => 
        processingController.enqueue(async () => {
          try {
            const linkedInUrl = await findLinkedInCompanyPage({
              website: company.website,
              name: company.name
            });
            
            if (linkedInUrl) {
              linkedInPages.push({ 
                ...company,
                linkedInUrl 
              });
              logger.success(`Found LinkedIn page for ${company.name || company.website}`);
            } else {
              const isWebsiteAvailable = await checkWebsiteAvailability(company.website);
              
              if (isWebsiteAvailable) {
                notFoundCompanies.push({ 
                  ...company,
                  name: company.name || extractCompanyNameFromUrl(company.website)
                });
                logger.warn(`No LinkedIn page found for ${company.name || company.website}, will use name-based search`);
              } else {
                failed.push({
                  website: company.website,
                  name: company.name,
                  reason: 'Website not accessible'
                });
                logger.warn(`Skipping ${company.name || company.website} - website not accessible`);
              }
            }
          } catch (error) {
            failed.push({ 
              website: company.website,
              name: company.name,
              reason: error.message 
            });
            logger.error(`Failed to process ${company.name || company.website}: ${error.message}`);
          }
        })
      )
    );

    let enrichedCompanies = [];
    if (linkedInPages.length > 0) {
      try {
        enrichedCompanies = await getCompanyDataBatch(linkedInPages);
        logger.success(`Successfully enriched and stored ${enrichedCompanies.length} companies`);
      } catch (error) {
        logger.error(`Enrichment failed: ${error.message}`);
      }
    }

    const processedCompanies = [];
    const enrichmentFailed = [];

    linkedInPages.forEach(page => {
      const enrichedData = enrichedCompanies.find(c => c.linkedin_url === page.linkedInUrl);
      if (enrichedData) {
        processedCompanies.push({
          name: enrichedData.name || page.name,
          website: page.website,
          linkedin_url: page.linkedInUrl,
          linkedin_id: enrichedData.linkedin_id,
          industry: enrichedData.industry,
          employee_count: enrichedData.employee_count,
          description: enrichedData.description,
          headquarters: enrichedData.headquarters
        });
      } else {
        enrichmentFailed.push({
          website: page.website,
          name: page.name || extractCompanyNameFromUrl(page.website)
        });
        logger.warn(`Enrichment failed for ${page.name || page.website}, will use name-based search`);
      }
    });

    const nameBasedCompanies = [
      ...notFoundCompanies,
      ...enrichmentFailed
    ].map(company => ({
      name: company.name,
      website: company.website
    }));

    // Store search results
    await storeSearchResult({
      batchNumber: 1,
      type: 'company-search',
      url: '',
      companies: processedCompanies.map(c => c.name)
    }, processedCompanies.length);

    // Generate Sales Navigator URLs
    const salesNavUrls = generateSalesNavUrls([
      ...processedCompanies,
      ...nameBasedCompanies
    ], titles);

    const result = {
      results: processedCompanies,
      nameBasedResults: nameBasedCompanies,
      failed: failed.map(f => f.website),
      processedCount: validCompanies.length,
      successCount: processedCompanies.length,
      nameBasedCount: nameBasedCompanies.length,
      failureReasons: failed.reduce((acc, f) => ({ ...acc, [f.website]: f.reason }), {}),
      salesNavUrls
    };

    logger.success(`Processing complete:
      - Total companies: ${result.processedCount}
      - Successfully enriched: ${result.successCount}
      - Name-based search: ${result.nameBasedCount}
      - Failed: ${result.failed.length}
      - Generated URLs: ${result.salesNavUrls.length}
    `);

    return result;
  } catch (error) {
    logger.error('Processing failed:', error);
    throw error;
  }
}
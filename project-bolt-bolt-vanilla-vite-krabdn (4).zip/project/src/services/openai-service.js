import OpenAI from 'openai';
import { config } from '../config/api-config.js';
import { logger } from '../utils/logger.js';
import { extractDomainFromUrl } from '../utils/url-validator.js';
import { RateController } from '../utils/rate-control.js';

const openai = new OpenAI({
  apiKey: config.openai.apiKey,
  dangerouslyAllowBrowser: true
});

// Configure rate controller for OpenAI
const rateController = new RateController({
  baseDelay: 1000,    // 1 second base delay
  maxDelay: 60000,    // 60 second max delay
  maxRetries: 3       // 3 retries maximum
});

async function cleanNameWithAI(name, context = '') {
  if (!name) return '';

  return rateController.enqueue(async () => {
    try {
      logger.debug(`Starting AI cleaning for: "${name}"${context ? ` (Context: ${context})` : ''}`);

      const prompt = `Clean this company name by removing legal suffixes while preserving the core business name, industry terms, and business type indicators.

Examples:
Input: "JustInTimeAviationParts LLC" | Context: Website: justintimeaviationparts.com
Output: JustInTime Aviation Parts

Input: "TURBINE ENGINE SOLUTIONS LLC" | Context: Website: turbineenginesolutions.info
Output: Turbine Engine Solutions

Input: "Aerofield Services, Inc." | Context: Website: aerofieldservices.com
Output: Aerofield Services

Input: "Turbojet Partners LLC" | Context: Website: turbojetinc.com
Output: Turbojet Partners

Current Input: "${name}"${context ? ` | Context: ${context}` : ''}
Output:`;

      const completion = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          {
            role: "system",
            content: `You are a company name standardization expert. Follow these rules strictly:
- Remove legal suffixes (LLC, Inc, Corp, Ltd, etc.)
- Preserve ALL industry-specific terms (Solutions, Services, Technologies, etc.)
- Preserve ALL business type indicators (Partners, Group, Associates, etc.)
- Keep special characters if part of the core name
- Use provided context (especially website domain) for better understanding
- Return ONLY the cleaned name without explanation or quotes
- Never remove words that are part of the core business name
- Preserve proper spacing between words
- Maintain appropriate capitalization
- Do not remove industry terms like "Solutions", "Services", etc.
- Keep hyphenated names intact
- Preserve location indicators (e.g., "International", "Global")`
          },
          {
            role: "user",
            content: prompt
          }
        ],
        temperature: 0.1,
        max_tokens: 1000,
        presence_penalty: -1,
        frequency_penalty: -1
      });

      const cleanedName = completion.choices[0].message.content.trim();
      
      if (cleanedName === name) {
        logger.debug(`No changes needed for "${name}"`);
      } else {
        logger.info(`Cleaned name: "${name}" -> "${cleanedName}"`);
      }
      
      return cleanedName;
    } catch (error) {
      if (error.response?.status === 429) {
        logger.warn(`Rate limit hit for "${name}", retrying after delay...`);
        throw error; // Let rate controller handle retry
      }
      logger.error(`AI cleaning failed for "${name}": ${error.message}`);
      return name;
    }
  });
}

export async function cleanCompanyNameWithAI(name, website = null) {
  if (!name) return '';
  
  try {
    const domain = website ? extractDomainFromUrl(website) : null;
    const context = domain ? `Website: ${domain}` : '';
    
    logger.debug(`Starting company name cleaning for "${name}" with context: ${context}`);
    
    const cleanedName = await cleanNameWithAI(name, context);
    return cleanedName;
  } catch (error) {
    logger.error(`Failed to clean company name "${name}": ${error.message}`);
    return name;
  }
}

export async function cleanLinkedInCompanyName(companyData) {
  if (!companyData?.companyName) {
    logger.debug('No company name to clean in LinkedIn data');
    return companyData;
  }

  try {
    const context = [
      companyData.industry,
      companyData.websiteUrl,
      companyData.description?.slice(0, 100)
    ].filter(Boolean).join(' | ');

    logger.debug(`Cleaning LinkedIn company name "${companyData.companyName}" with context: ${context}`);

    const cleanedName = await cleanNameWithAI(companyData.companyName, context);
    
    return {
      ...companyData,
      name: cleanedName,
      originalName: companyData.companyName
    };
  } catch (error) {
    logger.error(`Failed to clean LinkedIn company name: ${error.message}`);
    return companyData;
  }
}
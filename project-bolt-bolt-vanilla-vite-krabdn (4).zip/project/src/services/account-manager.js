import { config } from '../config/api-config';
import { logger } from '../utils/logger';

export class AccountManager {
  constructor() {
    this.accounts = new Map(
      config.unipile.accounts.map(id => [id, { 
        count: 0, 
        lastReset: Date.now(),
        currentCursor: null
      }])
    );
    this.currentIndex = 0;
  }

  resetUsageIfNeeded(accountId) {
    const now = Date.now();
    const dayInMs = 24 * 60 * 60 * 1000;
    const account = this.accounts.get(accountId);

    if (now - account.lastReset >= dayInMs) {
      account.count = 0;
      account.lastReset = now;
      account.currentCursor = null;
    }
  }

  getNextAvailableAccount() {
    const accountIds = Array.from(this.accounts.keys());
    const startIndex = this.currentIndex;
    
    for (let i = 0; i < accountIds.length; i++) {
      const index = (startIndex + i) % accountIds.length;
      const accountId = accountIds[index];
      
      this.resetUsageIfNeeded(accountId);
      const account = this.accounts.get(accountId);

      if (account.count < config.unipile.dailyLimit) {
        this.currentIndex = (index + 1) % accountIds.length;
        return accountId;
      }
    }

    return null;
  }

  updateUsage(accountId, count) {
    const account = this.accounts.get(accountId);
    if (account) {
      account.count += count;
      logger.info(`Account ${accountId} usage: ${account.count}/${config.unipile.dailyLimit}`);
    }
  }

  setCursor(accountId, cursor) {
    const account = this.accounts.get(accountId);
    if (account) {
      account.currentCursor = cursor;
    }
  }

  getCursor(accountId) {
    return this.accounts.get(accountId)?.currentCursor;
  }
}
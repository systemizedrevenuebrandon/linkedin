export function formatTenure(tenure) {
  if (!tenure) return '';
  const years = tenure.years || 0;
  const months = tenure.months || 0;
  return `${years}y ${months}m`;
}

export function formatDate(date) {
  if (!date) return '';
  const year = date.year || '';
  const month = date.month || '';
  return month ? `${year}-${month.toString().padStart(2, '0')}` : year.toString();
}

export function formatProfileForCsv(employee, result) {
  const currentPositions = employee.current_positions || [];
  const mainPosition = currentPositions[0] || {};
  const education = employee.education || [];

  return {
    // Basic Profile Information
    batch: result.batchNumber,
    search_type: result.type,
    full_name: employee.name,
    first_name: employee.first_name,
    last_name: employee.last_name,
    headline: employee.headline,
    location: employee.location,
    industry: employee.industry,
    linkedin_url: employee.linkedin_url,
    profile_image_url: employee.profile_picture_url,

    // Current Position Information (Primary)
    current_company: mainPosition.company || '',
    current_company_id: mainPosition.company_id || '',
    current_role: mainPosition.role || '',
    current_location: mainPosition.location || '',
    current_description: mainPosition.description || '',
    role_tenure: formatTenure(mainPosition.tenure_at_role),
    company_tenure: formatTenure(mainPosition.tenure_at_company),
    role_start_date: formatDate(mainPosition.start),
    role_end_date: formatDate(mainPosition.end),

    // Additional Current Positions
    additional_positions: currentPositions.slice(1).map(pos => 
      `${pos.role || ''} at ${pos.company || ''}`
    ).join('; '),

    // Work Experience
    work_experience: employee.work_experience?.map(exp => 
      `${exp.role || ''} at ${exp.company || ''} (${formatDate(exp.start)} - ${formatDate(exp.end)})`
    ).join('; '),

    // Education Details
    education_1_degree: education[0]?.degree || '',
    education_1_school: education[0]?.school || '',
    education_1_school_id: education[0]?.school_id || '',
    education_1_start: formatDate(education[0]?.start),
    education_1_end: formatDate(education[0]?.end),

    education_2_degree: education[1]?.degree || '',
    education_2_school: education[1]?.school || '',
    education_2_school_id: education[1]?.school_id || '',
    education_2_start: formatDate(education[1]?.start),
    education_2_end: formatDate(education[1]?.end),

    additional_education: education.slice(2).map(edu => 
      `${edu.degree || ''} from ${edu.school || ''} (${formatDate(edu.start)} - ${formatDate(edu.end)})`
    ).join('; ')
  };
}
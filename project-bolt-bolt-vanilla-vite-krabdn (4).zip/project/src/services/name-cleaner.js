import OpenAI from 'openai';
import { config } from '../config/api-config.js';
import { logger } from '../utils/logger.js';
import { supabase } from '../config/supabase.js';
import { RateController } from '../utils/rate-control.js';

const openai = new OpenAI({
  apiKey: config.openai.apiKey,
  dangerouslyAllowBrowser: true
});

const rateController = new RateController({
  baseDelay: 1000,
  maxDelay: 5000,
  maxRetries: 2
});

async function cleanNameWithAI(name) {
  if (!name) return null;
  
  try {
    const prompt = `Clean this LinkedIn profile name by removing unnecessary information such as pronouns, titles, degrees, certifications, or middle names. Keep only the first name and last name.

Examples:
- "Sarah Elizabeth Johnson (She/Her) - Tech Lead" -> "Sarah Johnson"
- "Dr. Michael Robert Smith, PhD, MBA" -> "Michael Smith"
- "James William Henry Thompson III" -> "James Thompson"
- "John-Paul Smith-Jones, CFA" -> "John Smith"
- "Maria A. Rodriguez-Garcia, MD" -> "Maria Rodriguez"
- "Robert (Bob) Williams Jr." -> "Robert Williams"
- "Winston Yan, MD PhD" -> "Winston Yan"
- "Eris Jordan, OD" -> "Eris Jordan"
- "Thomas Smith, DDS, FAGD" -> "Thomas Smith"

Name to clean: "${name}"

Return only the cleaned name without any explanation.`;

    const completion = await openai.chat.completions.create({
      model: config.openai.model,
      messages: [
        {
          role: "system",
          content: "You are a name cleaning expert. Return only the cleaned name without any explanation."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      temperature: 0.1,
      max_tokens: 100
    });

    const cleanedName = completion.choices[0].message.content.trim();

    // Validate the cleaned name has at least two parts
    const parts = cleanedName.split(' ').filter(Boolean);
    if (parts.length < 2) {
      throw new Error(`Invalid cleaned name format: "${cleanedName}"`);
    }

    return {
      first_name: parts[0],
      last_name: parts.slice(1).join(' '),
      full_name: cleanedName
    };
  } catch (error) {
    logger.error(`Failed to clean name "${name}": ${error.message}`);
    return null;
  }
}

async function findEmployeesNeedingNameCleaning() {
  try {
    // Build the pattern matching query
    const patterns = [
      'PhD', 'MD', 'MBA', 'CFA', 'Jr.', 'Sr.', 'III', 'IV',
      'DDS', 'OD', 'DO', 'DMD', 'DPM', 'DC', 'NP', 'PA',
      'FACP', 'FACS', 'FACOG', 'FAGD', 'MSc', 'BSc',
      '(', ')', ',', '-', '.', '&', ' and ', '  '
    ];

    const { data: employees, error } = await supabase
      .from('employees')
      .select('linkedin_id, full_name')
      .or(patterns.map(pattern => 
        `full_name.ilike.%${pattern}%`
      ).join(','))
      .order('created_at', { ascending: false });

    if (error) throw error;

    // Additional filtering for multi-word names and special characters
    return employees.filter(emp => {
      const name = emp.full_name;
      return name && (
        name.split(' ').length > 2 ||  // More than 2 words
        /[,\(\)\[\]\{\}\-\.\&\/\\]/.test(name) ||  // Contains special characters
        /([A-Z]{2,}|\d)/.test(name) ||  // Contains acronyms or numbers
        /\s{2,}/.test(name)  // Contains multiple spaces
      );
    });
  } catch (error) {
    logger.error('Failed to find employees needing name cleaning:', error);
    throw error;
  }
}

async function updateEmployeeName(employee, cleanedName) {
  try {
    const { error } = await supabase
      .from('employees')
      .update({
        first_name: cleanedName.first_name,
        last_name: cleanedName.last_name,
        full_name: cleanedName.full_name,
        name_cleaned_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .eq('linkedin_id', employee.linkedin_id);

    if (error) throw error;
    logger.success(`Updated names for employee ${employee.linkedin_id}: ${cleanedName.full_name}`);
    return true;
  } catch (error) {
    logger.error(`Failed to update employee ${employee.linkedin_id}: ${error.message}`);
    return false;
  }
}

export async function cleanEmployeeNames() {
  try {
    const employeesToClean = await findEmployeesNeedingNameCleaning();
    if (!employeesToClean?.length) {
      logger.info('No employees need name cleaning');
      return [];
    }

    logger.info(`Starting name cleaning for ${employeesToClean.length} employees`);

    const results = [];
    for (const employee of employeesToClean) {
      try {
        const cleanedName = await rateController.enqueue(() => 
          cleanNameWithAI(employee.full_name)
        );

        if (!cleanedName) continue;

        if (cleanedName.full_name !== employee.full_name) {
          logger.info(`Cleaned name: "${employee.full_name}" -> "${cleanedName.full_name}"`);
          const success = await updateEmployeeName(employee, cleanedName);
          
          results.push({
            linkedin_id: employee.linkedin_id,
            original_name: employee.full_name,
            cleaned_name: cleanedName.full_name,
            success
          });
        }
      } catch (error) {
        logger.error(`Failed to clean name for ${employee.linkedin_id}: ${error.message}`);
      }
    }

    const successful = results.filter(r => r.success).length;
    logger.success(`Cleaned ${successful}/${employeesToClean.length} employee names`);
    return results;
  } catch (error) {
    logger.error('Name cleaning process failed:', error);
    throw error;
  }
}
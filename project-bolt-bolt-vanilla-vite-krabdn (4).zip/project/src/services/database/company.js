import { supabase } from '../../config/supabase';
import { logger } from '../../utils/logger';

export async function storeCompanyData(company) {
  try {
    if (!company.name) {
      logger.warn('No company name provided, skipping');
      return null;
    }

    // First check if company exists by LinkedIn ID or URL
    let existingCompany = null;
    if (company.linkedin_id || company.linkedin_url) {
      const { data } = await supabase
        .from('companies')
        .select('id')
        .or(`linkedin_id.eq.${company.linkedin_id},linkedin_url.eq.${company.linkedin_url}`)
        .maybeSingle();
      
      existingCompany = data;
    }

    // Insert or update company
    const { data, error } = await supabase
      .from('companies')
      .upsert({
        id: existingCompany?.id,
        linkedin_id: company.linkedin_id || null,
        name: company.name,
        website: company.website,
        linkedin_url: company.linkedin_url || null,
        industry: company.industry,
        employee_count: company.employee_count,
        description: company.description,
        headquarters: company.headquarters,
        updated_at: new Date().toISOString()
      }, {
        onConflict: existingCompany ? 'id' : undefined
      })
      .select()
      .single();

    if (error) throw error;
    logger.success(`Stored company data for ${company.name}`);
    return data;
  } catch (error) {
    logger.error(`Failed to store company data for ${company.name}: ${error.message}`);
    return null;
  }
}

export async function findCompanyByLinkedInId(linkedinId) {
  try {
    if (!linkedinId) return null;

    const { data, error } = await supabase
      .from('companies')
      .select('id, name, linkedin_id')
      .eq('linkedin_id', linkedinId.toString())
      .maybeSingle();

    if (error) {
      logger.error(`Failed to find company by LinkedIn ID: ${error.message}`);
      return null;
    }

    return data;
  } catch (error) {
    logger.error(`Failed to find company by LinkedIn ID: ${error.message}`);
    return null;
  }
}

export async function findCompanyByName(companyName) {
  try {
    if (!companyName) return null;

    // Clean the company name for matching
    const cleanName = companyName
      .replace(/\s*·.*$/, '') // Remove everything after ·
      .replace(/\s+Full-time$/, '') // Remove "Full-time"
      .trim();

    const { data, error } = await supabase
      .from('companies')
      .select('id, name, linkedin_id')
      .ilike('name', cleanName)
      .maybeSingle();

    if (error) {
      logger.error(`Failed to find company by name: ${error.message}`);
      return null;
    }

    return data;
  } catch (error) {
    logger.error(`Failed to find company by name: ${error.message}`);
    return null;
  }
}
import { isValidUrl } from './url-validator.js';
import { logger } from './logger.js';

/**
 * Validates an array of website URLs
 * @param {string[]} websites - Array of website URLs to validate
 * @returns {boolean} True if input is valid
 */
export function validateInputs(websites) {
  if (!Array.isArray(websites) || websites.length === 0) {
    logger.error('No valid websites provided');
    return false;
  }

  const invalidUrls = websites.filter(url => !isValidUrl(url));
  if (invalidUrls.length > 0) {
    logger.warn(`Found ${invalidUrls.length} invalid websites:`);
    invalidUrls.forEach(url => logger.warn(`  - ${url}`));
  }

  return websites.length > invalidUrls.length;
}

/**
 * Normalizes website URLs by ensuring they have a protocol
 * @param {string[]} websites - Array of website URLs to normalize
 * @returns {string[]} Array of normalized URLs
 */
export function normalizeWebsites(websites) {
  return websites.map(website => {
    if (typeof website !== 'string') {
      return null;
    }
    const trimmed = website.trim();
    if (!trimmed) {
      return null;
    }
    return trimmed.startsWith('http') ? trimmed : `https://${trimmed}`;
  }).filter(Boolean);
}

/**
 * Validates and normalizes a single website URL
 * @param {string} website - Website URL to process
 * @returns {string|null} Normalized URL or null if invalid
 */
export function validateAndNormalizeWebsite(website) {
  if (!website || typeof website !== 'string') {
    return null;
  }

  const trimmed = website.trim();
  if (!trimmed) {
    return null;
  }

  const normalized = trimmed.startsWith('http') ? trimmed : `https://${trimmed}`;
  return isValidUrl(normalized) ? normalized : null;
}
import { logger } from './logger.js';
import { validateAndNormalizeWebsite } from './input-validator.js';

/**
 * Parses a CSV file and extracts website and company name data
 * @param {File} file - The CSV file to parse
 * @returns {Promise<Array>} Array of parsed company data
 */
export async function parseCSV(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = async (event) => {
      try {
        const text = event.target.result;
        const lines = text.split(/\r?\n/);
        
        if (lines.length < 2) {
          throw new Error('CSV file must contain at least a header row and one data row');
        }

        // Find header row and column indices
        const headers = lines[0].toLowerCase().split(',').map(h => h.trim());
        const websiteIndex = headers.findIndex(h => 
          h.includes('website') || h.includes('domain') || h.includes('url')
        );
        const nameIndex = headers.findIndex(h => 
          h.includes('company') || h.includes('name') || h.includes('organization')
        );
        
        if (websiteIndex === -1) {
          throw new Error('No website column found in CSV. Please include a column named "website", "domain", or "url"');
        }
        
        logger.info(`Found columns - Website: ${headers[websiteIndex]}, Company Name: ${nameIndex !== -1 ? headers[nameIndex] : 'Not found'}`);
        
        // Parse data rows
        const companies = [];
        const errors = [];

        for (let i = 1; i < lines.length; i++) {
          const line = lines[i].trim();
          if (!line) continue;

          const columns = line.split(',').map(col => col.trim());
          const websiteValue = columns[websiteIndex];
          const nameValue = nameIndex !== -1 ? columns[nameIndex] : null;

          if (!websiteValue) {
            errors.push(`Row ${i + 1}: Missing website value`);
            continue;
          }

          const normalizedWebsite = validateAndNormalizeWebsite(websiteValue);
          if (!normalizedWebsite) {
            errors.push(`Row ${i + 1}: Invalid website format - ${websiteValue}`);
            continue;
          }

          companies.push({
            website: normalizedWebsite,
            name: nameValue || null
          });
        }

        if (errors.length > 0) {
          logger.warn('CSV parsing warnings:', errors);
        }

        if (companies.length === 0) {
          throw new Error('No valid company data found in CSV');
        }

        logger.success(`Successfully parsed ${companies.length} companies from CSV`);
        logger.debug('Parsed companies:', companies);
        
        resolve(companies);
      } catch (error) {
        logger.error(`Failed to parse CSV: ${error.message}`);
        reject(error);
      }
    };
    
    reader.onerror = () => {
      logger.error('Failed to read CSV file');
      reject(new Error('Failed to read CSV file'));
    };
    
    reader.readAsText(file);
  });
}
import { config } from '../config/api-config';
import { logger } from '../utils/logger';
import { storeEmployeeData, storeSearchResult } from './database';
import { AccountManager } from './account-manager';
import { searchEmployees } from './linkedin-search';
import { mapEmployeeData } from '../utils/data-mappers';
import { runEnrichmentWorkflow } from './enrichment';

const accountManager = new AccountManager();

async function getAllProfiles(urlData) {
  const profiles = [];
  let cursor = null;
  let total = 0;

  try {
    const accountId = accountManager.getNextAvailableAccount();
    if (!accountId) {
      throw new Error('Daily limit reached for all accounts');
    }

    const firstPage = await searchEmployees(urlData.url, null, accountId);
    const processedFirstPage = await processProfileBatch(firstPage.profiles, urlData);
    profiles.push(...processedFirstPage);
    
    accountManager.updateUsage(accountId, firstPage.profiles.length);
    cursor = firstPage.cursor;
    total = firstPage.total;

    logger.info(`Found ${total} total profiles, processed ${profiles.length} so far`);

    while (cursor && profiles.length < total && profiles.length < config.unipile.dailyLimit) {
      const result = await searchEmployees(null, cursor, accountId);
      const processedProfiles = await processProfileBatch(result.profiles, urlData);
      profiles.push(...processedProfiles);
      
      accountManager.updateUsage(accountId, result.profiles.length);
      cursor = result.cursor;

      logger.info(`Processed ${profiles.length}/${total} profiles`);

      if (profiles.length + config.unipile.resultsPerPage > config.unipile.dailyLimit) {
        logger.warn('Approaching daily limit, stopping pagination');
        break;
      }
    }

    return profiles;
  } catch (error) {
    logger.error(`Failed to fetch all profiles: ${error.message}`);
    throw error;
  }
}

async function processProfileBatch(profiles, searchData) {
  const processedProfiles = [];

  for (const profile of profiles) {
    try {
      // Only map and store basic profile data initially
      const mappedProfile = mapEmployeeData(profile);
      if (!mappedProfile) continue;

      // Store without trying to link companies yet
      const storedProfile = await storeEmployeeData(mappedProfile, searchData);
      if (storedProfile) {
        processedProfiles.push(storedProfile);
      }
    } catch (error) {
      logger.error(`Failed to process profile ${profile.name}: ${error.message}`);
    }
  }

  return processedProfiles;
}

export async function processEmployeeUrls(urls) {
  try {
    if (!Array.isArray(urls) || urls.length === 0) {
      throw new Error('No URLs provided');
    }

    logger.info(`Processing ${urls.length} Sales Navigator URLs`);
    
    const results = [];
    const failed = [];

    for (const urlData of urls) {
      try {
        logger.info(`Processing batch ${urlData.batchNumber}: ${urlData.url}`);
        
        const employees = await getAllProfiles(urlData);
        await storeSearchResult(urlData, employees.length);

        results.push({
          ...urlData,
          employees,
          employeeCount: employees.length
        });

        logger.success(`Completed batch ${urlData.batchNumber}: Found and processed ${employees.length} employees`);
      } catch (error) {
        failed.push({
          ...urlData,
          error: error.message
        });
        logger.error(`Failed to process batch ${urlData.batchNumber}: ${error.message}`);
      }
    }

    // Start enrichment workflow after all profiles are stored
    if (results.some(r => r.employees.length > 0)) {
      logger.info('Starting enrichment workflow for new profiles');
      await runEnrichmentWorkflow();
    }

    return {
      results,
      failed,
      totalEmployees: results.reduce((sum, r) => sum + r.employeeCount, 0),
      processedUrls: results.length,
      failedUrls: failed.length
    };
  } catch (error) {
    logger.error('Employee data processing failed:', error);
    throw error;
  }
}
import { logger } from '../utils/logger';
import { storeEmployeeData } from './database';
import { mapEmployeeData } from '../utils/data-mappers';

export async function processProfileBatch(profiles, searchData) {
  const processedProfiles = [];

  // First pass: Store basic profile data
  for (const profile of profiles) {
    try {
      // Map the raw profile data
      const mappedProfile = mapEmployeeData(profile);
      if (!mappedProfile) continue;

      // Store the profile
      const storedProfile = await storeEmployeeData(mappedProfile, searchData);
      if (storedProfile) {
        processedProfiles.push(storedProfile);
      }
    } catch (error) {
      logger.error(`Failed to process profile ${profile.name}: ${error.message}`);
    }
  }

  return processedProfiles;
}
export function generateSingleSalesNavUrl(companyId) {
  return `https://www.linkedin.com/sales/company/${companyId}`;
}
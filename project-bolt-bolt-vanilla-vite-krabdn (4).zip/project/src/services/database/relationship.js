import { supabase } from '../../config/supabase';
import { logger } from '../../utils/logger';

export async function storeEmployeeCompanyRelationship(employeeId, position) {
  try {
    if (!employeeId || !position?.company) {
      logger.warn(`Missing required data for relationship: ${JSON.stringify({ employeeId, position })}`);
      return false;
    }

    // Ensure role is not null
    const role = position.role || 'Employee';

    // Store the relationship
    const { error } = await supabase
      .from('employee_companies')
      .upsert({
        employee_id: employeeId,
        company_id: position.company_id || null,
        company_name: position.company,
        role: role,
        is_current: !position.end,
        start_date: position.start ? `${position.start.year}-${position.start.month || '01'}-01` : null,
        end_date: position.end ? `${position.end.year}-${position.end.month || '01'}-01` : null
      }, {
        onConflict: 'employee_id,company_name,role'
      });

    if (error) {
      logger.error(`Failed to store relationship: ${error.message}`);
      return false;
    }

    logger.success(`Stored relationship for ${employeeId} at ${position.company}`);
    return true;
  } catch (error) {
    logger.error(`Failed to store employee-company relationship: ${error.message}`);
    return false;
  }
}

export async function findEmployeeRelationships(employeeId) {
  try {
    const { data, error } = await supabase
      .from('employee_companies')
      .select(`
        company_id,
        company_name,
        role,
        is_current,
        start_date,
        end_date,
        companies (
          id,
          name,
          linkedin_id,
          linkedin_url
        )
      `)
      .eq('employee_id', employeeId)
      .order('is_current', { ascending: false })
      .order('start_date', { ascending: false });

    if (error) throw error;
    return data || [];
  } catch (error) {
    logger.error(`Failed to find employee relationships: ${error.message}`);
    return [];
  }
}
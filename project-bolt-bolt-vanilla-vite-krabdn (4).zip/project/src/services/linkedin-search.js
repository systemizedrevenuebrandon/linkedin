import axios from 'axios';
import { config } from '../config/api-config';
import { logger } from '../utils/logger';
import { RateController } from '../utils/rate-control';

const rateController = new RateController({
  baseDelay: 2000,
  maxDelay: 30000,
  maxRetries: 3,
  maxRequestsPerWindow: 5,
  windowSize: 60000
});

export async function searchEmployees(url, cursor, accountId) {
  return rateController.enqueue(async () => {
    try {
      const response = await axios.post(
        `${config.unipile.baseUrl}?limit=${config.unipile.resultsPerPage}&account_id=${accountId}`,
        {
          api: 'classic',
          category: 'people',
          ...(cursor ? { cursor } : { url })
        },
        {
          headers: {
            'Content-Type': 'application/json',
            'X-API-KEY': config.unipile.apiKey
          }
        }
      );

      if (!response.data?.items) {
        throw new Error('Invalid response format from API');
      }

      return {
        profiles: response.data.items,
        cursor: response.data.cursor,
        total: response.data.paging?.total_count || 0
      };
    } catch (error) {
      logger.error(`Failed to fetch employees: ${error.message}`);
      throw error;
    }
  });
}